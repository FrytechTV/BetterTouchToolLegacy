//
//  BSTHotKeyRegistrator.m
//  BetterSnapTool
//
//  Created by Andreas Hegenberg on 16.11.10.
//  Copyright 2010 TUM. All rights reserved.
//

#import "BSTHotKeyRegistrator.h"
#import "PTKeyCombo.h"
#import "PTHotKey.h"
#import "PTHotKeyCenter.h"

@implementation BSTHotKeyRegistrator
@synthesize registeredHotKeys;

- (id)init{
	if (self = [super init]) {
		
		self.registeredHotKeys = [[NSMutableDictionary alloc] init];
		if ([[NSUserDefaults standardUserDefaults] objectForKey:@"registeredHotkeys"]) {
						
			NSEnumerator *enumerator = [[[NSUserDefaults standardUserDefaults] objectForKey:@"registeredHotkeys"] keyEnumerator];
			id key;
			while ((key = [enumerator nextObject])) {
				NSDictionary *combo = [[[NSUserDefaults standardUserDefaults] objectForKey:@"registeredHotkeys"] objectForKey:key];
				////////CLog(@"xx");
				[self addNewHotKeyForAction:[(NSString *)key integerValue] keyCodes:[[combo objectForKey:@"keyCode"] integerValue] modifierKeys:[[combo objectForKey:@"modifiers"] unsignedIntegerValue]];

			}
			self.registeredHotKeys = [[NSUserDefaults standardUserDefaults] objectForKey:@"registeredHotkeys"];

		}
		////////CLog([self.registeredHotKeys description]);
	}
	return self;
}

- (void) addNewHotKeyForAction:(NSInteger)theAction keyCodes:(NSInteger)kCodes modifierKeys:(NSInteger)mCodes {
	
	if (kCodes == -1 || kCodes == 0 && mCodes == 0) {
		return;
	}
	////////CLog(@"add");
	PTKeyCombo *combo = [[PTKeyCombo alloc] initWithKeyCode:kCodes modifiers:mCodes];
	combo.actionID = theAction;
	
	PTHotKey *hotkey = [[PTHotKey alloc] initWithIdentifier:@"BSTHotkey" keyCombo:combo];
	[[PTHotKeyCenter sharedCenter] registerHotKey:hotkey];
}

- (void) registerNewHotKeyForAction:(NSInteger)theAction keyCodes:(NSInteger)kCodes modifierKeys:(NSInteger)mCodes {
	BOOL remove = NO;
	NSDictionary *oldCombo;
		////////CLog(@"register1");
	if(oldCombo = [self.registeredHotKeys objectForKey:[NSString stringWithFormat:@"%i",theAction]]) {
		////////CLog(@"unregister now and here %@",[oldCombo description]);
		[[PTHotKeyCenter sharedCenter] unregisterHotKeyWithKeyCode:[[oldCombo objectForKey:@"keyCode"] integerValue] 
													   andModifier:[[oldCombo objectForKey:@"modifiers"]unsignedIntegerValue]];
		
		if (kCodes == -1 && mCodes == 0 ) {
			remove = YES;
		}
	}
	////////CLog(@"register");
	NSMutableDictionary *keyCombos = [[self.registeredHotKeys mutableCopy] autorelease];
	
		PTKeyCombo *combo = [[PTKeyCombo alloc] initWithKeyCode:kCodes modifiers:mCodes];
		combo.actionID = theAction;
		
		
		[keyCombos setObject:[combo plistRepresentation] 
					  forKey:[NSString stringWithFormat:@"%i",[combo actionID]]
		 
		 ];
		
		self.registeredHotKeys = keyCombos;
	if (!remove) {
		[self addNewHotKeyForAction:theAction keyCodes:kCodes modifierKeys:mCodes];
	} else {
		[keyCombos removeObjectForKey:[NSString stringWithFormat:@"%i",[combo actionID]]];
	}

	
	
	[[NSUserDefaults standardUserDefaults] setObject:keyCombos forKey:@"registeredHotkeys"];
	
}


@end
