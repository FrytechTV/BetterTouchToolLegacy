//
//  SecondBarWindowController.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 23.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SecondBarWindowController.h"
#import "SBAccessibility.h"
#import "CustomWindow.h"
#import "SBMenuButton.h"
#import "SBPrefsWindowController.h"

@implementation SecondBarWindowController
@synthesize contentView;
@synthesize sbWindow;
@synthesize tempView;
@synthesize sbPrefs;
@synthesize	menuCreator;
@synthesize SBButton;
@synthesize timeButton;
@synthesize appMenu;
@synthesize timeUpdater;

- (id)initWithWindowNibName:(NSString *)windowNibName {
	if (self = [super initWithWindowNibName:windowNibName ]) {
		self.menuCreator = [[SBAccessibility alloc] init];
        //CLog(@"init");
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(toggleWindowState:) name:@"showHideWindow" object:nil];

		[self start];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stop) name:@"windowHidden" object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(start) name:@"windowVisible" object:nil];
		
		[NSTimer scheduledTimerWithTimeInterval:0.4 target:self selector:@selector(createTimeButton) userInfo:nil repeats:NO];
			}
	return self;
}

- (void) hideWindow:(id)sender {
	
}

- (void) start {
	self.timeUpdater = [NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];

}

-(void) stop {
	[self.timeUpdater invalidate];
	self.timeUpdater = nil;
	
}

-(void)createTimeButton{
	self.SBButton = [[SBMenuButton alloc] init];
	self.SBButton.menu = self.appMenu;
	self.SBButton.tag = 666;
	//[[self.SBButton cell] setBackgroundStyle:NSBackgroundStyleRaised];
	[self.SBButton setFont:[NSFont systemFontOfSize:14]];

	
	[self updateTime];

	[self.contentView setAutoresizesSubviews: YES];

	[self.SBButton setAutoresizingMask:(NSViewMinXMargin | NSViewMinYMargin |
									 NSViewMaxXMargin | NSViewMaxYMargin)];

	[self.contentView addSubview:self.SBButton];
	
	
	}

- (IBAction) resetWindowPosition:(id)sender {
	[self.sbWindow setScreenTo:self.sbWindow.currentScreen];

}

- (void)updateTime {

	//NSDateFormatter *timeFormatter = [[[NSDateFormatter alloc] init] autorelease];
	//[timeFormatter setDateStyle:NSDateFormatterShortStyle];
	//	[timeFormatter setDateStyle:NSDateFormatterNoStyle];
	//	[timeFormatter setTimeStyle:NSDateFormatterShortStyle];
	//	NSDate *stringTime = [NSDate date];
	
	NSString *formattedDateStringTime =[NSDateFormatter localizedStringFromDate:[NSDate date] dateStyle:NSDateFormatterNoStyle timeStyle:NSDateFormatterShortStyle];
	
	//+ (NSString *)localizedStringFromDate:(NSDate *)date dateStyle:(NSDateFormatterStyle)dstyle timeStyle:(NSDateFormatterStyle)tstyle AVAILABLE_MAC_OS_X_VERSION_10_6_AND_LATER;

	
	//NSString *formattedDateStringTime = [timeFormatter stringFromDate:stringTime];
	formattedDateStringTime	= [formattedDateStringTime stringByAppendingString:@" ▿"];
	[self.SBButton setTitle:formattedDateStringTime];
		
	[self.SBButton sizeToFit];
	NSRect newFrame = NSMakeRect(self.sbWindow.frame.size.width-self.SBButton.frame.size.width, 0.0, self.SBButton.frame.size.width, 22);
	self.SBButton.frame =newFrame;
	
}	



- (void) removeAllButtons {
	NSArray *subviews = [[[self.contentView subviews] copy] autorelease];
	for (id subview in subviews) {
		NSButton *button = (NSButton *) subview;
		if(button.tag != 666) {
			[button removeFromSuperview];
		}
	}
	

	
}

- (IBAction) showPreferencesWindow :(id)sender {
	
	[[NSApplication	sharedApplication] activateIgnoringOtherApps:YES];

	[[SBPrefsWindowController sharedPrefsWindowController] showWindow:nil];

	
	
}

- (IBAction) toggleWindowState :(id)sender {
	self.sbWindow.visible =!self.sbWindow.visible;
	
}

- (void)dealloc {
 //[self.contentView release];
	[[NSNotificationCenter defaultCenter] removeObserver:self];

	[self.SBButton release];
	[self.appMenu release];
	[self.tempView release];
	[super dealloc];
}


@end
