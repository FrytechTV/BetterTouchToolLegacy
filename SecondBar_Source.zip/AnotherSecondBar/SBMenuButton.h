//
//  SBMenuButton.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 25.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface SBMenuButton : NSButton {
	NSTrackingArea *trackingArea;
	BOOL insideButton;
	NSMenu *menu;
	NSTimer *timer;

}

@property (nonatomic,retain) NSMenu *menu;
- (void) colorizeBlue;

@end
