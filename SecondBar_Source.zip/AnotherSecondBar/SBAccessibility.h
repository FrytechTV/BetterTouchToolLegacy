//
//  SBAccessibility.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 24.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@class SBMenuButton;

@interface SBAccessibility  : NSObject{
	NSInteger		menuItemCount;
	AXUIElementRef systemWide;
	AXUIElementRef window;
	AXUIElementRef ourWindow;
	AXObserverRef focusObserver;
	AXObserverRef windowObserver;

	NSMutableDictionary *currentApplicationMenu;
	NSMutableArray *menubarItems;

	NSLock *theLock;
	
	NSMutableDictionary *observer;
	
	BOOL watching;
	BOOL everythingEnabled;
	NSNumber *secondBarPid;
	NSNumber *lastPid;
	NSNumber *currentPid;

	
	NSTimer *timer;
	SBMenuButton *currentButton;
	//SBPopupMenu *currentlyOpenMenu;
	
	
}
typedef enum {
	SBWindowActionsMaximize					= 1,	
	SBWindowActionsLeft	=2,
	SBWindowActionsRight =3
		
} SBWindowActions;

@property(nonatomic,retain) SBMenuButton *currentButton;
@property(nonatomic,retain) NSTimer *timer;
@property (nonatomic,retain) NSMutableArray *menubarItems;
//@property (nonatomic,retain) NSMutableArray *subItems;

@property (nonatomic,retain) NSLock *theLock;
@property (nonatomic,retain) NSMutableDictionary *currentApplicationMenu;
@property (nonatomic,retain) NSMutableDictionary *observer;
@property (nonatomic) BOOL everythingEnabled;

@end
