//
//  CustomWindow.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 22.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "CustomWindow.h"
#import "SecondBarAppDelegate.h"
#import "SecondBarWindowController.h"

@implementation CustomWindow

@synthesize initialLocation;
@synthesize menubarItems;
@synthesize currentScreen;
@synthesize currentlyDragging;
@synthesize visible;
@synthesize transparency;

- (void) resetColor {
	NSColor *theBColor = [self backgroundAsColor] ;
	[self setBackgroundColor:theBColor];
	
	
}

- (id)initWithContentRect:(NSRect)contentRect styleMask:(NSUInteger)aStyle backing:(NSBackingStoreType)bufferingType defer:(BOOL)flag {
    // Using NSBorderlessWindowMask results in a window without a title bar.
    self = [super initWithContentRect:contentRect styleMask:NSNonactivatingPanelMask backing:NSBackingStoreBuffered defer:NO];
    if (self != nil) {
		self.transparency = [[[NSUserDefaults standardUserDefaults] objectForKey:@"transparency"] floatValue];
		//[self setLevel:NSFloatingWindowLevel];
		[self setLevel:kCGMaximumWindowLevel];
//[myWindow setLevel:kCGDesktopWindowLevel]; 
		
		//[self setBackgroundColor:[NSColor blueColor]];
        // Start with no transparency for all drawing into the window
		//  [self setAlphaValue:[[[NSUserDefaults standardUserDefaults] objectForKey:@"transparency"] floatValue]];
        // Turn off opacity so that the parts of the window that are not drawn into are transparent.
        [self setOpaque:NO];
	
		[self setCollectionBehavior:NSWindowCollectionBehaviorCanJoinAllSpaces];
	
	
		[self setCollectionBehavior:NSWindowCollectionBehaviorStationary];
		
		[self setBecomesKeyOnlyIfNeeded:YES];
		[self setAcceptsMouseMovedEvents:YES];
		[self setIgnoresMouseEvents:NO];
		self.worksWhenModal =YES;
		self.currentlyDragging = NO;
		[self setScreenTo:-1];
		[self setAllowsConcurrentViewDrawing:YES];
        	[self setCanBecomeVisibleWithoutLogin:NO];
		self.visible = YES;
	
		//[self  
			
		self.delegate = self;
		
		
		[[NSDistributedNotificationCenter defaultCenter] addObserver:self
															selector:@selector(startScreensaver) name:@"com.apple.screensaver.didstart" object:nil];
		
		[[NSDistributedNotificationCenter defaultCenter] addObserver:self
															selector:@selector(stopScreensaver) name:@"com.apple.screensaver.didstop" object:nil];
		
		
		[[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
															   selector:@selector(sessionBegin)
																   name:NSWorkspaceSessionDidBecomeActiveNotification
																 object:nil];
		
		[[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
															   selector:@selector(sessionEnd)
																   name:NSWorkspaceSessionDidResignActiveNotification
																 object:nil];
		
		
			
    }
    return self;
}


- (void) sessionBegin {
	[self setVisible:YES];
	[self setLevel:kCGMaximumWindowLevel];
}
- (void) sessionEnd {

	[self setVisible:NO];
	[self setLevel:kCGNormalWindowLevel];
}


- (void) startScreensaver {
	[self setLevel:kCGNormalWindowLevel];
}

- (void) stopScreensaver {
	[self setLevel:kCGMaximumWindowLevel];
}

-(BOOL) canBecomeKeyWindow {
	return NO;
}

-(BOOL) canBecomeMainWindow {
	return NO;
}

- (void) close {
	
}


-(void)adjustWindowWidth {
	[self setMaxSize:[[self screen] frame].size];

	if (self.frame.size.width < [self minSize].width) {
	//	////CLog(@"adjust");
	NSRect originalFrame = [self frame];
	NSRect newFrame =originalFrame;
	
//	SecondBarAppDelegate *delegate = [[NSApplication sharedApplication] delegate];
	newFrame.size.width= [self minSize].width;
		
	if(newFrame.size.width <= [self maxSize].width) {
		[self setFrame:newFrame display:YES animate:YES];
	}
	}

	
}


- (NSColor *)backgroundAsColor
{
	
	CGFloat _cornerRadius = 0;
	
	
    NSImage *bg = [[NSImage alloc] initWithSize:self.frame.size];
    [bg lockFocus];
    
	
	
	// Make background path
    NSRect bgRect = NSMakeRect(0, 0, [bg size].width, [bg size].height);
	

	
    int minX = NSMinX(bgRect);
    int midX = NSMidX(bgRect);
    int maxX = NSMaxX(bgRect);
    int minY = NSMinY(bgRect);
    int midY = NSMidY(bgRect);
    int maxY = NSMaxY(bgRect);
	
    NSBezierPath *bgPath = [NSBezierPath bezierPath];
    
	// Bottom edge and bottom-right curve.
    [bgPath moveToPoint:NSMakePoint(midX, minY)];
    [bgPath appendBezierPathWithArcFromPoint:NSMakePoint(maxX, minY) 
                                     toPoint:NSMakePoint(maxX, midY) 
                                      radius:_cornerRadius];
    
	// Right edge and top-right curve.
    [bgPath appendBezierPathWithArcFromPoint:NSMakePoint(maxX, maxY) 
                                     toPoint:NSMakePoint(midX, maxY) 
                                      radius:_cornerRadius];
    
	// Top edge and top-left curve.
    [bgPath appendBezierPathWithArcFromPoint:NSMakePoint(minX, maxY) 
                                     toPoint:NSMakePoint(minX, midY) 
                                      radius:_cornerRadius];
    
	// Left edge and bottom-left curve.
    [bgPath appendBezierPathWithArcFromPoint:bgRect.origin 
                                     toPoint:NSMakePoint(midX, minY) 
                                      radius:_cornerRadius];
    [bgPath closePath];
	
	NSColor *aColor = [NSColor colorWithCalibratedRed:0.756 green:0.756 blue:0.755 alpha:self.transparency];
	
	[aColor setFill];
	[bgPath fill];
	CGFloat fromALpha = 0.4;
	CGFloat toALpha = 1;
	
	if (self.transparency <= 0.1) {
		fromALpha = 0;
		toALpha = 0;
	} else if (self.transparency <= 0.4) {
		fromALpha = 0.2;
		toALpha = 0.6;
	}
	
	NSColor *fromColor = [NSColor colorWithCalibratedWhite:0.936 alpha:fromALpha];
	NSColor *toColor = [NSColor colorWithCalibratedWhite:0.585 alpha:toALpha];
	NSGradient *fillGradient = [[NSGradient alloc] initWithStartingColor:fromColor endingColor:toColor];
    [fillGradient drawInBezierPath:bgPath angle:-90.0];

	
	
	//[NSBezierPath fillRect: bgRect];
	//	[bgPath fill];
	//NSBezierPath * path = [NSBezierPath bezierPathWithRect:bgRect];
	[bgPath setLineWidth:1];
	


	NSColor *bColor = [NSColor colorWithCalibratedWhite:0.000 alpha:0.910];
	[bColor  setStroke];
	
	[NSBezierPath strokeLineFromPoint:NSMakePoint(minX, minY)  toPoint:NSMakePoint(maxX, minY) ];
	
	
	[bg unlockFocus];
    
    return [NSColor colorWithPatternImage:[bg autorelease]];
}


/*
 Start tracking a potential drag operation here when the user first clicks the mouse, to establish the initial location.
 */
- (void)mouseDown:(NSEvent *)theEvent {    
  if ([theEvent modifierFlags] & NSControlKeyMask) {  
	  [self setScreenTo:self.currentScreen];
     }else if ([theEvent modifierFlags] & NSAlternateKeyMask) {  
         // ...  
         }  
}

-(void)setVisible:(BOOL) isVisible {
	if(isVisible) {
		visible = YES;
		[[NSNotificationCenter defaultCenter] postNotificationName:@"windowVisible" object:self];
		[self makeKeyAndOrderFront:nil];
		[self setScreenTo:-1];
	} else {
		visible = NO;
		[self orderOut:nil];
		[[NSNotificationCenter defaultCenter] postNotificationName:@"windowHidden" object:self];
		
	}
	
	
}

-(void)rightMouseDown:(NSEvent *)theEvent {
	
	//TODO:showpopupmenu
}

/*
 Once the user starts dragging the mouse, move the window with it. The window has no title bar for the user to drag (so we have to implement dragging ourselves)
 */
- (void)mouseDragged:(NSEvent *)event {
	//NSPoint pointInView = [self convertPoint:[event locationInWindow] fromView:nil];
	self.currentlyDragging = YES;
	NSWindow *window = self;
	NSPoint originalMouseLocation = [window convertBaseToScreen:[event locationInWindow]];
	NSRect originalFrame = [window frame];
	BOOL draggable = [[[NSUserDefaults standardUserDefaults] objectForKey:@"draggable"] boolValue];
	[self setMaxSize:[[self screen] frame].size];

    while (YES && draggable)
	{
		
		//
		// Lock focus and take all the dragged and mouse up events until we
		// receive a mouse up.
		//
        NSEvent *newEvent = [window
							 nextEventMatchingMask:(NSLeftMouseDraggedMask | NSLeftMouseUpMask)];
		
        if ([newEvent type] == NSLeftMouseUp)
		{
			self.currentlyDragging = NO;
			break;
		}
		
		//
		// Work out how much the mouse has moved
		//
		NSPoint newMouseLocation = [window convertBaseToScreen:[newEvent locationInWindow]];
		NSPoint delta = NSMakePoint(
									newMouseLocation.x - originalMouseLocation.x,
									newMouseLocation.y - originalMouseLocation.y);
		
		NSRect newFrame = originalFrame;
	
		
		//resizing
		if (!([event modifierFlags] & NSAlternateKeyMask))
		{
			//
			// Alter the frame for a drag
			//
			newFrame.origin.x += delta.x;
			newFrame.origin.y += delta.y;
		}
		else
		{
			//
			// Alter the frame for a resize
			//
			newFrame.size.width += delta.x;
			
			
			//
			// Constrain to the window's min and max size
			//
			NSRect newContentRect = [window contentRectForFrameRect:newFrame];
			NSSize maxSize = [window maxSize];
			NSSize minSize = [window minSize];
			if (newContentRect.size.width > maxSize.width)
			{
				newFrame.size.width -= newContentRect.size.width - maxSize.width;
			}
			else if (newContentRect.size.width < minSize.width)
			{
				newFrame.size.width += minSize.width - newContentRect.size.width;
			}
			if (newContentRect.size.height > maxSize.height)
			{
				newFrame.size.height -= newContentRect.size.height - maxSize.height;
				newFrame.origin.y += newContentRect.size.height - maxSize.height;
			}
			else if (newContentRect.size.height < minSize.height)
			{
				newFrame.size.height += minSize.height - newContentRect.size.height;
				newFrame.origin.y -= minSize.height - newContentRect.size.height;
			}
		}
	//	////CLog(@"%f",newFrame.origin.y);
		[window setFrame:newFrame display:YES animate:NO];
		

	}
	NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
	NSScreen *myScreen = [self screen];
	
	if(self.currentScreen != [allScreens indexOfObject:myScreen]) {
		//////CLog(@"setnewsize");
		[self setScreenTo:[allScreens indexOfObject:myScreen]];
		//////CLog(@"index %u", [allScreens indexOfObject:myScreen]);
	}
	self.currentlyDragging = NO;
	
	
	}

- (void)windowDidChangeScreen:(NSNotification *)notification {

	
	
	if(!self.currentlyDragging) {
		//////CLog(@"changed screen");
		if([[NSScreen screens] count] < 2) {
			self.visible = NO;
		}
		else {
			self.visible = YES;
			[self setMaxSize:[self screen].frame.size];
		}
		

	}
	
}

- (IBAction) changeScreen:(id)sender {
	
	NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
	if (self.currentScreen+1 < [allScreens count]) {
		[self setScreenTo:self.currentScreen+1];	
			//////CLog(@"screen1");
	}
	else {
		//////CLog(@"screen0");
		[self setScreenTo:0];
	}

}

- (void) setScreenTo:(NSInteger)screenNumber {
	
	NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
	NSRect screenVisibleFrame;
	NSRect screenNotVisibleFrame;

		if (screenNumber == -1) {
			if ([allScreens count] >= 2) {
				screenVisibleFrame = [[allScreens objectAtIndex:1] visibleFrame];
				screenNotVisibleFrame = [[allScreens objectAtIndex:1] frame];
				self.currentScreen = 1;
			}
			else {
				screenVisibleFrame = [[allScreens objectAtIndex:0] visibleFrame];
				screenNotVisibleFrame = [[allScreens objectAtIndex:0] frame];
				self.currentScreen = 0;
			}
		}
		else {
			screenVisibleFrame = [[allScreens objectAtIndex:screenNumber] visibleFrame];
			screenNotVisibleFrame = [[allScreens objectAtIndex:screenNumber] frame];
			
			self.currentScreen = screenNumber;
		}
		CGFloat width= CGRectGetWidth(NSRectToCGRect(screenNotVisibleFrame));
		
		CGFloat height = screenVisibleFrame.size.height;
		
//		NSPoint newPosition = NSMakePoint(screenVisibleFrame.origin.x, height+screenVisibleFrame.origin.y-22);
		NSRect newFrame = NSMakeRect(screenNotVisibleFrame.origin.x, height+screenVisibleFrame.origin.y-22, width, 22);
		

		[self setFrame:newFrame display:YES]; 
	NSColor *theBColor = [self backgroundAsColor] ;
	[self setBackgroundColor:theBColor];
}

- (void)setScreen {
	NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
	NSRect screenVisibleFrame;
	NSRect screenNotVisibleFrame;
	if ([allScreens count] >= 2) {
		screenVisibleFrame = [[allScreens objectAtIndex:1] visibleFrame];
		screenNotVisibleFrame = [[allScreens objectAtIndex:1] frame];

	}
	else {
		screenVisibleFrame = [[allScreens objectAtIndex:0] visibleFrame];
		screenNotVisibleFrame = [[allScreens objectAtIndex:0] frame];
	}

	CGFloat width= CGRectGetWidth(NSRectToCGRect(screenVisibleFrame));
	CGFloat height = screenVisibleFrame.size.height;

	NSPoint newPosition = NSMakePoint(screenNotVisibleFrame.origin.x, height+screenVisibleFrame.origin.y-22);
	NSRect newFrame = NSMakeRect(self.frame.origin.x, self.frame.origin.y, width, 22);
	[self setFrame:newFrame display:YES]; 
	//	self.frame.size.width=width;
	[self setFrameOrigin:newPosition];
	//GFloat screenWidth = (CGFloat) screenVisibleFrame.size.width;
	//[self.frame.size setWidth:screenWidth];
	NSColor *theBColor = [self backgroundAsColor] ;
	[self setBackgroundColor:theBColor];
	
}



@end
