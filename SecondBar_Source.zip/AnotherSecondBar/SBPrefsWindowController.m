//
//  SBPrefsWindowController.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 10/27/09.
//  Copyright 2009 SecondBar. All rights reserved.
//

#import "SBPrefsWindowController.h"
#import "SecondBarAppDelegate.h"
#import "CustomWindow.h"
#import "SecondBarWindowController.h"



@implementation SBPrefsWindowController
@synthesize version;


-(void)configureShortcutrecorder:(SRRecorderControl*)theControl {
    
    [theControl setAllowsKeyOnly:NO escapeKeysRecord:NO];
	[theControl setAllowedFlags: 0+NSCommandKeyMask+NSAlternateKeyMask+NSControlKeyMask+NSShiftKeyMask+NSFunctionKeyMask];
    
    

}

-(void)showWindow:(id)sender {
    [self.window center];
	[super showWindow:sender];
    
    [self configureShortcutrecorder:globalHide1];
    [self configureShortcutrecorder:globalOpenPreferences0];
    NSDictionary *allcombos = [[NSUserDefaults standardUserDefaults] objectForKey:@"registeredHotkeys"];
    
    if ([allcombos objectForKey:@"0"]) {
        
        
        [globalOpenPreferences0 setKeyCombo:SRMakeKeyCombo(
                                        [[[allcombos objectForKey:@"0"] objectForKey:@"keyCode"] integerValue], 
                                        SRCarbonToCocoaFlags( [[ [allcombos objectForKey:@"0"] objectForKey:@"modifiers"] integerValue])
                                        
                                        )];	
	}
	
	
	if ([allcombos objectForKey:@"1"]) {
		[globalHide1 setKeyCombo:SRMakeKeyCombo(
										[[[allcombos objectForKey:@"1"] objectForKey:@"keyCode"] integerValue], 
										SRCarbonToCocoaFlags( [[ [allcombos objectForKey:@"1"] objectForKey:@"modifiers"] integerValue])
										
										)];	
	}

}


- (void)shortcutRecorder:(SRRecorderControl *)aRecorder keyComboDidChange:(KeyCombo)newKeyCombo {
	
	////////CLog(@"ding");
	[[APPDEL hotkeyRegistrator] registerNewHotKeyForAction:[aRecorder tag] 
                                                  keyCodes:[aRecorder keyCombo].code
                                              modifierKeys:SRCocoaToCarbonFlags([aRecorder keyCombo].flags) ];
	
    
}


-(IBAction) setHotkey:(id)sender {
	////////CLog(@"set");
	SRRecorderControl *shortcutControl = (SRRecorderControl *)sender;
	[APPDEL.hotkeyRegistrator registerNewHotKeyForAction:[shortcutControl tag] 
                                                keyCodes:[shortcutControl keyCombo].code
                                            modifierKeys:SRCocoaToCarbonFlags([shortcutControl keyCombo].flags) ];
	
    
}



-(id) initWithWindow:(NSWindow *)window {
	NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
	
	NSString *versionString = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
	self.version= [NSString stringWithFormat:@"Version %@ by Andreas Hegenberg", 
				   versionString];
	return [super initWithWindow:window];
	
}
- (void)setupToolbar
{
	
	[self addView:generalPrefsView label:@"General"];
	


}




- (IBAction) setTransparency:(id)sender {
	NSSlider *slider = (NSSlider *)sender;
	SecondBarAppDelegate *delegate = [[NSApplication sharedApplication] delegate];
	CustomWindow *sbWindow = delegate.sbWindowController.sbWindow;
	[sbWindow setTransparency:slider.floatValue];
	[sbWindow resetColor];
}



-(IBAction) setDockIcon:(id)sender {
	if([[[NSUserDefaults standardUserDefaults] objectForKey:@"dockIcon"] boolValue]) {
		ProcessSerialNumber psn = { 0, kCurrentProcess };
		// display dock icon
		TransformProcessType(&psn, kProcessTransformToForegroundApplication);
	}
	
}

- (void) dealloc {
	[self.version release];
	[super dealloc];
}

@end
