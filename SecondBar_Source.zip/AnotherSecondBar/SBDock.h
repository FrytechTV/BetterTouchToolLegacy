//
//  SBDock.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 13.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SBDock : NSObject {

}

@end
