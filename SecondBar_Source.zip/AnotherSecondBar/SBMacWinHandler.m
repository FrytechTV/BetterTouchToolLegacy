//
//  SBMacWinHandler.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 09.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SBMacWinHandler.h"
#import "SBApiAccess.h"
#import "SecondBarAppDelegate.h"
#import "CustomWindow.h"
#import "SecondBarWindowController.h"


@interface SBMacWinHandler()

@property (nonatomic) BOOL watching;

@end

@implementation SBMacWinHandler
@synthesize watching;



-(id) init {
	self=[super init];
	if(self != nil) {
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stop) name:@"windowHidden" object:nil];	
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(start) name:@"windowVisible" object:nil];
		systemWide = AXUIElementCreateSystemWide();	
		self.watching = YES;
	}
	return self;
}
-(void) stop {
	self.watching = NO;
}
-(void) start {
	self.watching = YES;
}

- (IBAction) maximizeCurrentWindow:(id)sender {
	NSMenuItem *senderItem = (NSMenuItem *)sender;
	[self changeWindowSize:senderItem.tag];
}

-(void) setNextFocused:(BOOL)focused {
	
}

- (void) arrangeApplicationsWindows {
	
}

- (void) bringWindowToScreen:(NSInteger)screenNumber {
	
}



-(void) changeWindowSize:(NSInteger)parameter {
	
	NSWorkspace *ws = [NSWorkspace sharedWorkspace];
	if ( ![[[ws activeApplication] objectForKey:@"NSApplicationName"] isEqualToString:@"SecondBar"]) {
		AXUIElementRef app = (AXUIElementRef)[SBApiAccess
											  valueOfExistingAttribute:kAXFocusedApplicationAttribute 
											  ofUIElement:systemWide];
		AXUIElementRef *myWindow = (AXUIElementRef *)[SBApiAccess 
												   valueOfExistingAttribute:kAXFocusedWindowAttribute 
												   ofUIElement:app];
		
		//TODO:maybe check if focused window exists
		if(myWindow) {
			[self changeWindowSize:parameter forWindow:myWindow];
		}
		else {
			////CLog(@"error change window size");
		}
	}
}
-(void) changeWindowSize:parameter forWindow:myWindow{
	//////CLog(@"param: %i",parameter);
	NSPoint point = NSMakePoint(0, 0);
	[self changeWindowSize:parameter forWindow:myWindow isSmooth:NO mousePosition:point];
}


-(void) changeWindowSize:(NSInteger)parameter forWindow:(AXUIElementRef *) myWindow isSmooth:(BOOL)smooth mousePosition:(NSPoint)mousePos{
	BOOL withoutMenubar;
	CGSize windowSize;
	CGPoint windowPosition;
	CFTypeRef temp;

	if( AXUIElementCopyAttributeValue(
									  (AXUIElementRef) myWindow, kAXSizeAttribute, (CFTypeRef *)&temp
									  ) == kAXErrorSuccess) {
		AXValueGetValue(temp, kAXValueCGSizeType, &windowSize);
		if (temp) {
			CFRelease(temp);
		} else {
			return;
		}
		
		if (AXUIElementCopyAttributeValue(
										  (AXUIElementRef) myWindow, kAXPositionAttribute, (CFTypeRef *)&temp
										  ) ==kAXErrorSuccess) {
			AXValueGetValue(temp, kAXValueCGPointType, &windowPosition);
		}
		if (temp) {
			CFRelease(temp);
		} else {
			return;
		}
		
		//after this convertedWindowPos is the y of the left bottom corner of the window.
		NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
		NSRect mainScreenFrame = [[allScreens objectAtIndex:0] visibleFrame];
		CGFloat convertedWindowPos = mainScreenFrame.size.height -windowSize.height -windowPosition.y;
		windowPosition.y = convertedWindowPos+windowSize.height/2;
		windowPosition.x = windowPosition.x + windowSize.width/2;
		
		for (int i = 0; i < [allScreens count]; i++) {
			
			BOOL dockHidden = NO;
			NSScreen *myScreen = [allScreens objectAtIndex: i];
			NSRect myScreenVisibleFrame;
			if (ABS([myScreen frame].origin.x - [myScreen visibleFrame].origin.x) < 7)  {
				dockHidden = YES;
				////CLog(@"dock hidden");
				myScreenVisibleFrame = [myScreen frame];
				
			
			} else {
				myScreenVisibleFrame = [myScreen visibleFrame];
				
			}


			
			NSInteger shouldMoveToOtherMonitor;
			//next monitor TODO: this doesn't really work and could be removed
			if (parameter == SBWindowPositioningNextMonitor || parameter == SBWindowPositioningMaximizeNext || parameter == SBWindowPositioningLeftHalfNext ) {
				shouldMoveToOtherMonitor = 1;
				//previous monitor
			} else if (parameter == SBWindowPositioningPreviousMonitor) {
				shouldMoveToOtherMonitor = 2;
			} else {
				shouldMoveToOtherMonitor = 0;
			}
			
			if (parameter == SBWindowPositioningPreviousMonitor) {
				parameter = SBWindowPositioningNextMonitor;
			}
			
			//TODO: check
			NSRect framey = myScreen.frame;
			framey.size.height+=1;
			framey.size.width +=1;
			if ((NSPointInRect(NSPointFromCGPoint(windowPosition),framey) && !smooth) || smooth && NSPointInRect(mousePos, framey)){
				if(shouldMoveToOtherMonitor == 1) {
					//next monitor
					myScreen = [allScreens objectAtIndex:((i+1) % [allScreens count])];
				} else if (shouldMoveToOtherMonitor == 2) {
					//previous monitor
					myScreen = [allScreens objectAtIndex:((i-1) % [allScreens count])];
				}
				
				if (parameter == SBWindowPositioningLeftHalf || parameter ==SBWindowPositioningMaximize || parameter == SBWindowPositioningMaximizeNext || parameter == SBWindowPositioningLeftHalfNext || parameter == SBWindowPositioningNextMonitor || parameter == SBWindowPositioningMaximizeLeftHalf) {
					windowPosition.x = myScreenVisibleFrame.origin.x;
					////CLog(@"left: %f",windowPosition.x);

					
				} else if (parameter == SBWindowPositioningRightHalf || parameter == SBWindowPositioningRightHalfNext || parameter == SBWindowPositioningMaximizeRightHalf) {
					windowPosition.x = myScreenVisibleFrame.origin.x + myScreenVisibleFrame.size.width*0.5;
				}
				
				BOOL visible = NO;
				
				
				windowPosition.y = [[allScreens objectAtIndex:0] frame].size.height- [myScreen frame].size.height- [myScreen frame].origin.y;
				
				if (parameter != SBWindowPositioningRightHalf && parameter != SBWindowPositioningLeftHalf && parameter != SBWindowPositioningNextMonitor) {
					if (withoutMenubar) {
						windowSize.height = myScreenVisibleFrame.size.height;
					} else {
						windowSize.height = myScreenVisibleFrame.size.height;
					}
					
					
				}
				
				if (parameter == SBWindowPositioningMaximize || parameter == SBWindowPositioningMaximizeNext) {
					//BTTLog(@"%f", [myScreen visibleFrame].size.width);
					
					windowSize.width = myScreenVisibleFrame.size.width;
					////CLog(@"width %f",windowSize.width);
				} else if (parameter == SBWindowPositioningLeftHalf  || parameter == SBWindowPositioningLeftHalfNext || parameter == SBWindowPositioningMaximizeLeftHalf) {
					windowSize.width = myScreenVisibleFrame.size.width *0.5;
					//BTTLog(@"%f , window: %f", [myScreen visibleFrame].size.width,windowSize.width);
				} else if (parameter == SBWindowPositioningRightHalf || parameter == SBWindowPositioningRightHalfNext || parameter == SBWindowPositioningMaximizeRightHalf) {
					windowSize.width = myScreenVisibleFrame.size.width *0.5;
					//BTTLog(@"%f , window: %f", [myScreen visibleFrame].size.width,windowSize.width);
				}
				
				
				//	windowPosition.y = myScreen.frame.origin.y;
				temp = AXValueCreate(kAXValueCGPointType, &windowPosition);
				AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXPositionAttribute, temp);
				if (temp) {
					CFRelease(temp);
				} else {
					return;
				}
				temp = AXValueCreate(kAXValueCGSizeType, &windowSize);
		
				AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXSizeAttribute, temp);
				if (temp) {
					CFRelease(temp);
				} else {
					return;
				}
				
				
				if( AXUIElementCopyAttributeValue(
												  (AXUIElementRef) myWindow, kAXSizeAttribute, (CFTypeRef *)&temp
												  ) == kAXErrorSuccess) {
					AXValueGetValue(temp, kAXValueCGSizeType, &windowSize);
					if (temp) {
						CFRelease(temp);
					} else {
						return;
					}
					
					if (AXUIElementCopyAttributeValue(
													  (AXUIElementRef) myWindow, kAXPositionAttribute, (CFTypeRef *)&temp
													  ) ==kAXErrorSuccess) {
						AXValueGetValue(temp, kAXValueCGPointType, &windowPosition);
					}
					if (temp) {
						CFRelease(temp);
					} else {
						return;
					}
					//BTTLog(@"main: x %f , y %f",mainScreenFrame.origin.x,mainScreenFrame.origin.y);
					//BTTLog(@"width: %f height: %f y: %f x: %f screen height: %f width: %f x:%f, y %f", windowSize.width,windowSize.height,windowPosition.y,windowPosition.x,[myScreen visibleFrame].size.height,[myScreen visibleFrame].size.width,[myScreen visibleFrame].origin.x,[myScreen visibleFrame].origin.y);
					
					BOOL moveAgain = NO;
					//	BTTLog(@"ff %i",i);					
					if (i==0 && windowPosition.y == 0.0) // Dock on left
					{
						windowPosition.y +=22;
						moveAgain=YES;

					}
					
					if ((windowPosition.x+windowSize.width) > (myScreenVisibleFrame.origin.x+myScreenVisibleFrame.size.width)) {
						windowPosition.x -= (windowPosition.x+windowSize.width)-(myScreenVisibleFrame.origin.x+myScreenVisibleFrame.size.width);
						moveAgain = YES;
					}
					
					
					if(moveAgain) {
						////CLog(@"again");
						temp = AXValueCreate(kAXValueCGPointType, &windowPosition);
						AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXPositionAttribute, temp);
						if (temp) {
							CFRelease(temp);
						} else {
							return;
						}
						temp = AXValueCreate(kAXValueCGSizeType, &windowSize);
						AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXSizeAttribute, temp);
						if (temp) {
							CFRelease(temp);
						} else {
							return;
						}
					}
				}
				return;
			}
		}
	}
}
// -------------------------------------------------------------------------------
//	FlippedScreenBounds:bounds
// -------------------------------------------------------------------------------
static NSRect FlippedScreenBounds(NSRect bounds)
{
    float screenHeight = NSMaxY([[[NSScreen screens] objectAtIndex:0] frame]);
    bounds.origin.y = screenHeight - NSMaxY(bounds);
    return bounds;
}


//- (void) checkScreen2 {
//	if(self.watching) {
//		if([[[NSUserDefaults standardUserDefaults] objectForKey:@"moveWindows"] boolValue]) {
//			AXUIElementRef systemWide = AXUIElementCreateSystemWide();		
//			// get the currently active application  
//			AXUIElementRef app = (AXUIElementRef)[SBApiAccess
//												  valueOfExistingAttribute:kAXFocusedApplicationAttribute 
//												  ofUIElement:systemWide];
//			NSWorkspace *ws = [NSWorkspace sharedWorkspace];
//			if ( ![[[ws activeApplication] objectForKey:@"NSApplicationName"] isEqualToString:@"SecondBar"]) {
//				// Get the window that has focus for this application
//				NSArray *myWindows = (NSArray *)[SBApiAccess 
//												 valueOfExistingAttribute:kAXWindowsAttribute 
//												 ofUIElement:app];
//				
//				CGSize windowSize;
//				CGPoint windowPosition;
//				SecondBarAppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];
//				NSRect secondBarFrame = appDelegate.sbWindowController.sbWindow.frame;
//				
//				for (id myWindow in myWindows) {
//					
//					NSString *stringy1  = [SBApiAccess 
//										   valueOfExistingAttribute:kAXSubroleAttribute 
//										   ofUIElement:(AXUIElementRef) myWindow];
//					if(![stringy1 isEqualToString: @"AXUnknown"]) {
//						
//						
//						/* Get the window size and position */
//						
//						CFTypeRef tempSize;
//						if( AXUIElementCopyAttributeValue(
//														  (AXUIElementRef) myWindow, kAXSizeAttribute, (CFTypeRef *)&tempSize
//														  ) == kAXErrorSuccess) {
//							AXValueGetValue(tempSize, kAXValueCGSizeType, &windowSize);
//							CFRelease(tempSize);
//							
//							CFTypeRef tempPosition;
//							if( AXUIElementCopyAttributeValue(
//															  (AXUIElementRef) myWindow, kAXPositionAttribute, (CFTypeRef *)&tempPosition
//															  ) == kAXErrorSuccess) {
//								AXValueGetValue(tempPosition, kAXValueCGPointType, &windowPosition);
//								CFRelease(tempPosition);
//							}
//							//get screensize
//							NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
//							NSRect mainScreenFrame = [[allScreens objectAtIndex:0] frame];
//							//NSRect screenVisibleFrame = [[allScreens objectAtIndex:1] frame];
//							
//							//after this convertedWindowPos is the y of the left bottom corner of the window.
//							CGFloat convertedWindowPos = mainScreenFrame.size.height -windowSize.height -windowPosition.y;
//							if(
//							   
//								//window below secondbar (or higher)
//							   (convertedWindowPos+windowSize.height - secondBarFrame.origin.y) > 0 
//							   //not higher than 40 (if monitor placed on top)
//							   && (convertedWindowPos+windowSize.height - secondBarFrame.origin.y) <40 
//							   //some space left and right up to which it will move
//							   && windowPosition.x >= (secondBarFrame.origin.x -50 ) 
//							   && windowPosition.x <= (secondBarFrame.origin.x + secondBarFrame.size.width) +50) {
//								
//								windowPosition.y = windowPosition.y+(convertedWindowPos+windowSize.height - secondBarFrame.origin.y);
//								CFTypeRef tempNewPosition = AXValueCreate(kAXValueCGPointType, &windowPosition);
//								AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXPositionAttribute, tempNewPosition);
//								CFRelease(tempNewPosition);
//								if(windowSize.height >= [appDelegate.sbWindowController.sbWindow screen].frame.size.height -22) {
//									windowSize.height -=(convertedWindowPos+windowSize.height - secondBarFrame.origin.y);
//								}
//								
//								
//								CFTypeRef tempNewSize = AXValueCreate(kAXValueCGSizeType, &windowSize);
//								AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXSizeAttribute, tempNewSize);
//								CFRelease(tempNewSize);
//								
//							}
//						}
//					}
//				}
//				
//			}
//			
//		}
//	}
//}

- (void) checkScreen {
	if(self.watching) {
		if([[[NSUserDefaults standardUserDefaults] objectForKey:@"moveWindows"] boolValue]) {
			
			// get the currently active application  
			AXUIElementRef app = (AXUIElementRef)[SBApiAccess
												  valueOfExistingAttribute:kAXFocusedApplicationAttribute 
												  ofUIElement:systemWide];
			
			//NSWorkspace *ws = [NSWorkspace sharedWorkspace];
			//if ( ![[[ws activeApplication] objectForKey:@"NSApplicationName"] isEqualToString:@"SecondBar"]) {
			// Get the window that has focus for this application
			AXUIElementRef *myWindow = (AXUIElementRef
										*)[SBApiAccess 
												   valueOfExistingAttribute:kAXFocusedWindowAttribute
												   ofUIElement:app];
			
			CGSize windowSize;
			CGPoint windowPosition;
			SecondBarAppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];
			NSRect secondBarFrame = appDelegate.sbWindowController.sbWindow.frame;
			
			
			
			
			
			
			/* Get the window size and position */
			
			CFTypeRef tempSize;
			if( AXUIElementCopyAttributeValue(
											  (AXUIElementRef) myWindow, kAXSizeAttribute, (CFTypeRef *)&tempSize
											  ) == kAXErrorSuccess) {
				AXValueGetValue(tempSize, kAXValueCGSizeType, &windowSize);
				CFRelease(tempSize);
				
				CFTypeRef tempPosition;
				if( AXUIElementCopyAttributeValue(
												  (AXUIElementRef) myWindow, kAXPositionAttribute, (CFTypeRef *)&tempPosition
												  ) == kAXErrorSuccess) {
					AXValueGetValue(tempPosition, kAXValueCGPointType, &windowPosition);
					CFRelease(tempPosition);
				}
				//get screensize
				NSArray *allScreens = [NSArray arrayWithArray:[NSScreen screens]];
				NSRect mainScreenFrame = [[allScreens objectAtIndex:0] frame];
				//NSRect screenVisibleFrame = [[allScreens objectAtIndex:1] frame];
				
				//after this convertedWindowPos is the y of the left bottom corner of the window.
				CGFloat convertedWindowPos = mainScreenFrame.size.height -windowSize.height -windowPosition.y;
				if(
				   
				   //window below secondbar (or higher)
				   (convertedWindowPos+windowSize.height - secondBarFrame.origin.y) > 0 
				   //not higher than 40 (if monitor placed on top)
				   && (convertedWindowPos+windowSize.height - secondBarFrame.origin.y) <40 
				   //some space left and right up to which it will move
				   && windowPosition.x >= (secondBarFrame.origin.x -50 ) 
				   && windowPosition.x <= (secondBarFrame.origin.x + secondBarFrame.size.width) +50) {
					NSString *stringy1  = [SBApiAccess 
										   valueOfExistingAttribute:kAXSubroleAttribute 
										   ofUIElement:(AXUIElementRef) myWindow];
					if(![stringy1 isEqualToString: @"AXUnknown"]) {
						
						windowPosition.y = windowPosition.y+(convertedWindowPos+windowSize.height - secondBarFrame.origin.y);
						CFTypeRef tempNewPosition = AXValueCreate(kAXValueCGPointType, &windowPosition);
						BOOL settable = NO;
						
						AXUIElementIsAttributeSettable((AXUIElementRef) myWindow, kAXPositionAttribute, &settable);
						if (!settable) {
							//CLog(@"oh no");
						} else	{
							//CLog(@"yes");
						}
                        BOOL resize= NO;
                        if(windowSize.height >= [appDelegate.sbWindowController.sbWindow screen].frame.size.height -22) {
                            //CLog(@"resize");
                            resize=YES;
							windowSize.height -=(convertedWindowPos+windowSize.height - secondBarFrame.origin.y)+22;
                            
						}
						
						CFTypeRef tempNewSize = AXValueCreate(kAXValueCGSizeType, &windowSize);
						AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXSizeAttribute, tempNewSize);
						CFRelease(tempNewSize);

						AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXPositionAttribute, tempNewPosition);
						CFRelease(tempNewPosition);
                        if (resize) {
                            windowSize.height +=22;
                        CFTypeRef tempNewSize2 = AXValueCreate(kAXValueCGSizeType, &windowSize);
						AXUIElementSetAttributeValue((AXUIElementRef) myWindow, kAXSizeAttribute, tempNewSize2);
						CFRelease(tempNewSize2);
                        }
                        
											}
					
				}
			}
			
			
			
		}
	}
}

-(void) dealloc {
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[super dealloc];

}

@end
