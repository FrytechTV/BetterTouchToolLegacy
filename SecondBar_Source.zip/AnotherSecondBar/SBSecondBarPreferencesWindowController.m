//
//  SBSecondBarPreferencesWindowController.m
//  SecondBar
//
//  Created by Andi on 06.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SBSecondBarPreferencesWindowController.h"


@implementation SBSecondBarPreferencesWindowController

@end
