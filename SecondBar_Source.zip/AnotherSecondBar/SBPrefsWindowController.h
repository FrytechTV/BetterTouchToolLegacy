//
//  SBPrefsWindowController.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 10/27/09.
//  Copyright 2009 SecondBar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DBPrefsWindowController.h"
#import <ShortcutRecorder/ShortcutRecorder.h>

@interface SBPrefsWindowController : DBPrefsWindowController {
	IBOutlet NSView *generalPrefsView;
	IBOutlet NSView *advancedPrefsView;
	IBOutlet NSView *windowPositioningPrefsView;
    IBOutlet SRRecorderControl *globalOpenPreferences0;
	IBOutlet SRRecorderControl *globalHide1;


	NSString *version;
}



@property (nonatomic,retain) NSString *version;


- (IBAction) setTransparency:(id)sender;
-(IBAction) setDockIcon:(id)sender;

@end
