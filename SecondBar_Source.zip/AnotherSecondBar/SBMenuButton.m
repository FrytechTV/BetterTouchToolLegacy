//
//  SBMenuButton.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 25.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SBMenuButton.h"
#import "SecondBarAppDelegate.h"


@implementation SBMenuButton
@synthesize menu;



- (void) test {
	
}

-(id) init{
	self = [super init];
	if (self != nil) {
		
		[self setBordered:NO];
		
		[self setButtonType:NSMomentaryChangeButton];
		[self setFont:[NSFont systemFontOfSize:14]];
		
		//[self setCanDrawConcurrently:YES];
		
		
	}	
	return self;
	
}

- (id) initWithFrame:(NSRect) frame {
	
	self = [super initWithFrame:frame];
	if (self != nil) {

		[self setBordered:NO];
		
		[self setButtonType:NSMomentaryChangeButton];
		[self setFont:[NSFont systemFontOfSize:14]];

		//[self setCanDrawConcurrently:YES];

		
			}	
	return self;
}

- (void)rightMouseDown:(NSEvent *)theEvent {
	

	[[NSNotificationCenter defaultCenter] postNotificationName:@"buttonPressed" object:self];

	NSRect frame = [self frame];

    NSPoint menuOrigin = NSMakePoint(frame.origin.x, frame.origin.y-4);
	NSEvent *event =  [NSEvent mouseEventWithType:NSRightMouseDown
                                         location:menuOrigin
                                    modifierFlags:theEvent.modifierFlags // 0x100
                                        timestamp:1
                                     windowNumber:theEvent.windowNumber
                                          context:nil
                                      eventNumber:0
                                       clickCount:1
                                         pressure:1.0];

	[super rightMouseDown:event];
	[self mouseUp:event];

}
-(NSMenu*) menuForEvent:(NSEvent *)event {
	////CLog(@"menu");
	return [super menuForEvent:event];
	
}



-(void)setTitle:(NSString *)aString {
    
    [super setTitle:aString];
    
	NSColor *color = [NSColor blackColor];
	
	NSMutableAttributedString *colorTitle =
	[[NSMutableAttributedString alloc] initWithAttributedString:[self attributedTitle]];
	
	NSRange titleRange = NSMakeRange(0, [colorTitle length]);
	
	[colorTitle addAttribute:NSForegroundColorAttributeName
					   value:color
					   range:titleRange];
	
	[self setAttributedTitle:colorTitle];
	[colorTitle release];
	
	[self needsDisplay];
   
	

}


- (void) colorizeBlue {
	NSColor *aColor = [NSColor selectedMenuItemColor];
	if (!self.menu) {
		aColor = [NSColor redColor];
	}
	[self.cell setBackgroundColor:aColor];
	
	NSColor *color = [NSColor whiteColor];
	
	NSMutableAttributedString *colorTitle =
	[[NSMutableAttributedString alloc] initWithAttributedString:[self attributedTitle]];
	
	NSRange titleRange = NSMakeRange(0, [colorTitle length]);
	
	[colorTitle addAttribute:NSForegroundColorAttributeName
					   value:color
					   range:titleRange];
	
	[self setAttributedTitle:colorTitle];
	[colorTitle release];
	
	[self needsDisplay];
	
}

- (void) colorizeLoading {
	NSColor *aColor = [NSColor colorWithCalibratedRed:0.606 green:0.233 blue:1.0 alpha:1.000];
	if (!self.menu) {
		aColor = [NSColor redColor];
	}
	[self.cell setBackgroundColor:aColor];
	
	NSColor *color = [NSColor whiteColor];
	
	NSMutableAttributedString *colorTitle =
	[[NSMutableAttributedString alloc] initWithAttributedString:[self attributedTitle]];
	
	NSRange titleRange = NSMakeRange(0, [colorTitle length]);
	
	[colorTitle addAttribute:NSForegroundColorAttributeName
					   value:color
					   range:titleRange];
	
	[self setAttributedTitle:colorTitle];
	[colorTitle release];
	
	[self needsDisplay];
	
}
- (void)mouseDown:(NSEvent *)theEvent
{	
	[self colorizeBlue];

	if ([theEvent modifierFlags] & NSControlKeyMask) {
		SecondBarAppDelegate *delegate = [[NSApplication sharedApplication] delegate];
		[delegate.sbWindowController resetWindowPosition:self];
		
	}else {
	[self rightMouseDown:theEvent];
	}
	
}


- (void)mouseUp:(NSEvent *)theEvent
{

	if(self.tag ==0) {
		[self.cell setBackgroundColor:nil];
		[self setTitle:@"    "];

	}
	[self.cell setBackgroundColor:nil];
	[self setTitle:self.title];

}

- (void) rightMouseUp:(NSEvent *)theEvent {
	NSEvent *event =  [NSEvent mouseEventWithType:NSRightMouseDown
										 location:[theEvent locationInWindow]
									modifierFlags:theEvent.modifierFlags // 0x100
										timestamp:theEvent.timestamp
									 windowNumber:theEvent.windowNumber
										  context:theEvent.context
									  eventNumber:theEvent.eventNumber
									   clickCount:1
										 pressure:1.0];
	

	[self.window postEvent:event atStart:YES];
}

- (void) dealloc {
	[menu release];
	[super dealloc];
}

@end
