//
//  SBMacWinHandler.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 09.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface SBMacWinHandler : NSObject {
	BOOL watching;
	AXUIElementRef		systemWide;
}

typedef enum {
	SBWindowPositioningMaximize					= 0,	
	SBWindowPositioningMaximizeNext	= 1,
	SBWindowPositioningLeftHalf = 2,
	SBWindowPositioningLeftHalfNext = 3,
	SBWindowPositioningRightHalf = 4,
	SBWindowPositioningRightHalfNext = 5,
	SBWindowPositioningMaximizeRightHalf = 6,
	SBWindowPositioningMaximizeLeftHalf = 7,
	SBWindowPositioningNextMonitor = 8,
	SBWindowPositioningPreviousMonitor = 9
	
	
} SBWindowPositioning;


-(void) changeWindowSize:(NSInteger)parameter forWindow:(AXUIElementRef *) myWindow;
- (IBAction) maximizeCurrentWindow:(id)sender;
-(void) changeWindowSize:(NSInteger)parameter;

@end
