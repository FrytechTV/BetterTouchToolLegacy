//
//  SecondBarWindowController.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 23.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
@class CustomWindow;
@class SBAccessibility;
@class SBMenuButton;

@class SBPreferencesWindowController;

@interface SecondBarWindowController : NSWindowController {
	IBOutlet NSView *contentView; 
	NSView *tempView;
	IBOutlet CustomWindow *sbWindow;
	SBPreferencesWindowController *sbPrefs;
	SBAccessibility *menuCreator;
	SBMenuButton *timeButton;
	IBOutlet SBMenuButton *SBButton;
	IBOutlet NSMenu *appMenu;
	NSTimer *timeUpdater;
}

@property (nonatomic,retain) IBOutlet SBMenuButton *SBButton;
@property (nonatomic,retain) SBMenuButton *timeButton;
@property (nonatomic,retain) IBOutlet NSView *contentView;
@property (nonatomic,retain) IBOutlet CustomWindow *sbWindow;
@property (nonatomic,retain) NSView *tempView;
@property (nonatomic,retain) SBPreferencesWindowController *sbPrefs;
@property (nonatomic,retain) SBAccessibility *menuCreator;
@property (nonatomic,retain) IBOutlet NSMenu *appMenu;
@property (nonatomic,retain) NSTimer *timeUpdater;


- (void) removeAllButtons; 
-(void) updateTime;
-(void) start;
- (IBAction) showPreferencesWindow:(id)sender;
- (IBAction) resetWindowPosition:(id)sender;
- (IBAction) toggleWindowState:(id)sender;
@end
