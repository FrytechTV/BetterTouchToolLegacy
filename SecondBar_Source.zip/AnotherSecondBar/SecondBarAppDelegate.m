//
//  SecondBarAppDelegate.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 22.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SecondBarAppDelegate.h"
#import "SecondBarWindowController.h"
#import "CustomWindow.h"
#import "SBAccessibility.h"
#import <AppKit/NSAccessibility.h>
#import <Carbon/Carbon.h>
#import "SBMacWinHandler.h"




@implementation SecondBarAppDelegate
@synthesize label;
@synthesize sbWindowController;
//@synthesize access; 
@synthesize windowMover;
@synthesize mainMenu;
@synthesize  hotkeyRegistrator;
//TODOLIST
//TODO: cache menuitems while menubar is still active
//TODO: everything what needs to be done if the window is draggable (save window position, deactivate windowmoving etc., contectmenuposition etc.)

OSStatus MyHotKeyHandler(EventHandlerCallRef nextHandler,EventRef theEvent,
						 SBMacWinHandler *userData)
{
	EventHotKeyID hkCom;
	GetEventParameter(theEvent,kEventParamDirectObject,typeEventHotKeyID,NULL,
					  sizeof(hkCom),NULL,&hkCom);
	int l = hkCom.id;
	
	switch (l) {
		case 1: //do something
			[userData changeWindowSize:SBWindowPositioningMaximize];
			break;
		case 2: //do something
			[userData changeWindowSize:SBWindowPositioningMaximizeLeftHalf];
			break;
		case 3: //do something
			[userData changeWindowSize:SBWindowPositioningMaximizeRightHalf];
			break;
		case 4: //do something
			[[NSApplication sharedApplication] terminate:nil];
			break;
		case 5:
			[[NSNotificationCenter defaultCenter] postNotificationName:@"showHideWindow" object:nil];
		
			break;
	}
	return noErr;
}

- (void) awakeFromNib {
	//Register the Hotkeys
	EventHotKeyRef gMyHotKeyRef;
	EventHotKeyID gMyHotKeyID;
	EventTypeSpec eventType;
	eventType.eventClass=kEventClassKeyboard;
	eventType.eventKind=kEventHotKeyPressed;

	
	
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults]; 
    NSDictionary *appDefaults = [NSDictionary
								 dictionaryWithObjectsAndKeys:
								 [NSNumber numberWithFloat:0.9], @"transparency",
								 [NSNumber numberWithBool:YES], @"moveWindows",
								 [NSNumber numberWithBool:YES],@"globalHotkeys",
								  [NSNumber numberWithBool:NO],@"dockIcon",
								 [NSNumber numberWithInteger:SBWindowPositioningMaximize],@"greenButtonRight",
								 [NSNumber numberWithInteger:SBWindowPositioningMaximizeLeftHalf],@"redButtonRight",
								 [NSNumber numberWithInteger:SBWindowPositioningMaximizeRightHalf],@"yellowButtonRight",
								 [NSNumber numberWithInteger:SBWindowPositioningMaximizeNext],@"greenButtonCMDRight",
								 [NSNumber numberWithInteger:SBWindowPositioningLeftHalfNext],@"redButtonCMDRight",
								 [NSNumber numberWithInteger:SBWindowPositioningRightHalfNext],@"yellowButtonCMDRight",
								 [NSNumber numberWithBool:YES], @"showOnStartIfOnlyOnMonitor",
								 [NSNumber numberWithBool:YES], @"otherMouseDoesCMDClick",
								 [NSNumber numberWithBool:YES], @"windowPositioningActivated",
								 [NSNumber numberWithBool:NO], @"draggable", nil];
	
		[defaults registerDefaults:appDefaults];
		self.windowMover = [[SBMacWinHandler alloc] init];
	
	
		if([[[NSUserDefaults standardUserDefaults] objectForKey:@"dockIcon"] boolValue]) {
		ProcessSerialNumber psn = { 0, kCurrentProcess };
		// display dock icon
		TransformProcessType(&psn, kProcessTransformToForegroundApplication);
	}
	//
//	if([[[NSUserDefaults standardUserDefaults] objectForKey:@"globalHotkeys"] boolValue]) {
//	InstallApplicationEventHandler(&MyHotKeyHandler,1,&eventType,self.windowMover,NULL);
//		////CLog(@"activating hotkeys");
//	//hotkey2: ctrl+cmd+alt+up
//	gMyHotKeyID.signature='htk1';
//	gMyHotKeyID.id=1;
//	RegisterEventHotKey(126, cmdKey+optionKey+controlKey, gMyHotKeyID,
//						GetApplicationEventTarget(), 0, &gMyHotKeyRef);
//	//hotkey1: ctrl+cmd+alt+left
//	gMyHotKeyID.signature='htk2';
//	gMyHotKeyID.id=2;
//	RegisterEventHotKey(123, cmdKey+optionKey+controlKey, gMyHotKeyID,
//						GetApplicationEventTarget(), 0, &gMyHotKeyRef);
//	
//	//hotkey2: ctrl+cmd+alt+right
//	gMyHotKeyID.signature='htk3';
//	gMyHotKeyID.id=3;
//	RegisterEventHotKey(124, cmdKey+optionKey+controlKey, gMyHotKeyID,
//						GetApplicationEventTarget(), 0, &gMyHotKeyRef);
//	
//	gMyHotKeyID.signature='htk4';
//	gMyHotKeyID.id=4;
//	RegisterEventHotKey(12, cmdKey+optionKey+controlKey, gMyHotKeyID,
//						GetApplicationEventTarget(), 0, &gMyHotKeyRef);
//
//	gMyHotKeyID.signature='htk5';
//	gMyHotKeyID.id=5;
//	RegisterEventHotKey(4, cmdKey+optionKey+controlKey, gMyHotKeyID,
//						GetApplicationEventTarget(), 0, &gMyHotKeyRef);
//	
//}

}

pascal OSErr menuBarShownHidden (EventHandlerCallRef inHandlerRef,
								 EventRef inEvent, void *data) {

    return [[NSApp delegate] menuBarShownHidden:inEvent];
}

- (OSStatus)menuBarShownHidden:(EventRef)inEvent
{
	//CLog(@"bing");
    if (GetEventKind(inEvent) == kEventMenuBarShown) {
        //CLog(@"kEventMenuBarShown");
    [sbWindowController.sbWindow setVisible:YES];
	}else {
			[sbWindowController.sbWindow setVisible:NO];
	        //CLog(@"kEventMenuBarHidden");
	}

    return 0;
}

-(void)toggleSecondbarVisibility {
    
    if (![sbWindowController.sbWindow isVisible]) {
        [sbWindowController.sbWindow setVisible:YES];

    } else {
        [sbWindowController.sbWindow setVisible:NO];

    }
    
}

-(void)openPreferences{
    [sbWindowController showPreferencesWindow:nil];
    
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
  	
	self.mainMenu = [[NSMenu alloc] initWithTitle:@"Main Menu"];
	NSMenuItem *item1 = [[NSMenuItem alloc] initWithTitle:@"Preferences" action:@selector(showPreferencesWindow:) keyEquivalent:@";"];
	[item1 setKeyEquivalentModifierMask:NSCommandKeyMask];
	[item1 setTarget:self];
	
	NSMenuItem *item2 = [[NSMenuItem alloc] initWithTitle:@"Quit Secondbar" action:@selector(terminate)	keyEquivalent:@"q" ];
	[item2 setKeyEquivalentModifierMask:NSCommandKeyMask];
	[item2 setTarget:self];
	
	[mainMenu addItem:item1];
	[mainMenu addItem:item2];
	
	[NSApp setMainMenu:self.mainMenu];

    // We first have to check if the Accessibility APIs are turned on.  If not, we have to tell the user to do it (they'll need to authenticate to do it).  If you are an accessibility app (i.e., if you are getting info about UI elements in other apps), the APIs won't work unless the APIs are turned on.	
    if (!AXAPIEnabled())
    {
        int ret = NSRunAlertPanel (@"SecondBar requires the Accessibility API to be enabled.  Would you like me to launch System Preferences so that you can turn on \"Enable access for assistive devices\".", @"", @"OK", @"Quit SecondBar", @"Cancel");
        
        switch (ret)
        {
            case NSAlertDefaultReturn: {
                
                NSDictionary *options = [NSDictionary dictionaryWithObjectsAndKeys:(id)kCFBooleanTrue, kAXTrustedCheckOptionPrompt, nil];
                
                if(AXIsProcessTrustedWithOptions((__bridge CFDictionaryRef)options)) {
               
                }
                break;
            }

            case NSAlertAlternateReturn:
				
                [NSApp terminate:self];
                return;
                break;
            case NSAlertOtherReturn: // just continue
            default:
                break;
				
        }
    }
    sbWindowController = [[SecondBarWindowController alloc] initWithWindowNibName:@"SBBar"];
    
    [sbWindowController showWindow:nil];

	if (![[[NSUserDefaults standardUserDefaults] objectForKey:@"showOnStartIfOnlyOnMonitor"] boolValue] && [[NSScreen screens] count] < 2) {
		[sbWindowController.sbWindow setVisible:NO];
	}
    self.hotkeyRegistrator = [[BSTHotKeyRegistrator alloc] init];
    
	EventTypeSpec opt[] =
    {
        { kEventClassMenu, kEventMenuBarShown },
        { kEventClassMenu, kEventMenuBarHidden }
    };
	
    OSStatus err;
    err=InstallEventHandler(GetEventDispatcherTarget
							(),NewEventHandlerUPP((EventHandlerProcPtr) menuBarShownHidden),
							2,opt,nil,nil);
    
    
	[[SUUpdater sharedUpdater] setDelegate:self];
   
}




@end
