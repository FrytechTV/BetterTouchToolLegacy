//
//  SecondBarAppDelegate.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 22.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>
#import "BSTHotKeyRegistrator.h"
#import <Sparkle/Sparkle.h>
@class SecondBarWindowController;
@class SBAccessibility;
@class SBMacWinHandler;

@interface SecondBarAppDelegate : NSObject {
	IBOutlet NSTextField *label;
	SecondBarWindowController *sbWindowController;
	//SBAccessibility *access;
	SBMacWinHandler *windowMover;
	NSMenu *mainMenu;
	BSTHotKeyRegistrator *hotkeyRegistrator;
}

@property (assign) IBOutlet NSTextField *label;
@property (nonatomic,retain) SecondBarWindowController *sbWindowController;
//@property (nonatomic,retain) SBAccessibility *access;
@property (nonatomic,retain) SBMacWinHandler *windowMover;
@property (nonatomic,retain) IBOutlet NSMenu *mainMenu;
@property (nonatomic, retain) BSTHotKeyRegistrator *hotkeyRegistrator;

@end
