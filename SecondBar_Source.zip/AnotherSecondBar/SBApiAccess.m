//
//  SBApiAccess.m
//  SecondBar
//
//  Created by Andreas Hegenberg on 12.09.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "SBApiAccess.h"



@implementation SBApiAccess



+ (id)valueOfExistingAttribute:(CFStringRef)attribute ofUIElement:(AXUIElementRef)element
{
    id result = nil;
    NSArray *attrNames;
	
    if (AXUIElementCopyAttributeNames(element, (CFArrayRef *)&attrNames) == kAXErrorSuccess) 
    {
        if ( [attrNames indexOfObject:(NSString *)attribute] != NSNotFound
			&&
            AXUIElementCopyAttributeValue(element, attribute, (CFTypeRef *)&result) == kAXErrorSuccess
			) 
        {
            [result autorelease];
        }
        [attrNames release];
    }

    return result;
	
}

+ (NSString *)descriptionOfValue:(CFTypeRef)theValue beingVerbose:(BOOL)beVerbose
{
    NSString *	theValueDescString	= NULL;
	
    if (theValue) {
		if (CFGetTypeID(theValue) == AXUIElementGetTypeID()) { 
            
            NSString *uiElementTitle = [SBApiAccess valueOfExistingAttribute:kAXTitleAttribute 
																	 ofUIElement:(AXUIElementRef)theValue];
			
			if (uiElementTitle != nil) {
				theValueDescString = [NSString stringWithFormat:@"%@", uiElementTitle];
			}
			
		}
        else {
			//seperator
            theValueDescString = @"";
        }
    }
	
	if (!theValueDescString) {
		theValueDescString = @"    ";
	}
	
    return theValueDescString;
}




@end
