
#import "SBAccessibility.h"
#import "SecondBarWindowController.h"
#import "SecondBarAppDelegate.h"
#import "SBMacWinHandler.h"
#import <Carbon/Carbon.h>
#import <CoreServices/CoreServices.h>
#import "SBMenuButton.h"
#import "CustomWindow.h"
#import "SBApiAccess.h"

CFMachPortRef eventTap = nil;



@interface SBAccessibility()
@property (nonatomic,retain) NSNumber *secondBarPid;
@property (nonatomic,retain) NSNumber *lastPid;
@property (nonatomic,retain) NSNumber *currentPid;
@property (nonatomic) BOOL watching;

- (void) updateCurrentMenubar;
-(void) updateCurrentMenubarSoon;

//- (void) setupAppFrontSwitchedHandler;

//Observer methods
- (void)applicationLaunched:(NSNotification *)notification;
- (void)applicationTerminated:(NSNotification *)notification;
- (void)registerForAppSwitchNotificationFor:(NSDictionary *)application;
- (void) setupAppFrontSwitchedHandler;
- (void) registerForSwitchNotificationsForAppPID:(pid_t)pid;


- (void) updateNSMenuForMenubarItem:(AXUIElementRef)theItem andMenu:(NSMenu*)theMenu;
@end

@implementation SBAccessibility
@synthesize menubarItems;
//@synthesize subItems;
@synthesize currentApplicationMenu;
//@synthesize currentlyOpenMenu;
@synthesize theLock;
@synthesize observer;
@synthesize secondBarPid;
@synthesize lastPid;
@synthesize currentPid;
@synthesize timer;
@synthesize currentButton;
@synthesize watching;
@synthesize everythingEnabled;
#pragma mark -
#pragma mark Initializers
-(void) stop {
	self.watching = NO;
}
-(void) start {
	self.watching = YES;
}



CGEventRef HandleMouseEvent(int type, CGEventRef event)
{
    
	CGPoint ptMouse = CGEventGetLocation(event);
	
	//###################
	AXUIElementRef element = nil;
	AXUIElementRef systemWideC = AXUIElementCreateSystemWide();	
	AXUIElementSetMessagingTimeout(systemWideC,0.4);
    
	
	if (!AXUIElementCopyElementAtPosition(systemWideC, ptMouse.x, ptMouse.y, &element) == kAXErrorSuccess) {
        
		return nil;
	}
	
	if(! element) return nil;
	[((id) element) autorelease];
	
	AXUIElementRef subRole = (AXUIElementRef) [SBApiAccess 
											   valueOfExistingAttribute:kAXSubroleAttribute 
											   ofUIElement:element];
	
	
	if(! subRole) return nil;
	
	NSString* strSubRole = (NSString*) subRole;
	NSInteger roleNumber = 0;
	////CLog(strSubRole);
	if([strSubRole isEqualToString: @"AXZoomButton"])
	{
		if(type==1) {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"greenButtonCMDRight"] integerValue];
		} else {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"greenButtonRight"] integerValue];
		}
		
	} else if([strSubRole isEqualToString: @"AXCloseButton"]){
		if(type==1) {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"redButtonCMDRight"] integerValue];
		} else {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"redButtonRight"] integerValue];
		}
		
	}else if([strSubRole isEqualToString: @"AXMinimizeButton"]){
		if(type==1) {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"yellowButtonCMDRight"] integerValue];
		} else {
			roleNumber = [[[NSUserDefaults standardUserDefaults] objectForKey:@"yellowButtonRight"] integerValue];
		}
		
	}
	
	if(roleNumber >= 0 && roleNumber <= 5)
	{
		////CLog(@"role:%i",roleNumber);
		AXUIElementRef *windowUnderCursor = (AXUIElementRef *) [SBApiAccess valueOfExistingAttribute:kAXWindowAttribute 
                                                                                         ofUIElement:element];
        
		if(! windowUnderCursor) return event;
		
		SBMacWinHandler *handler = [[SBMacWinHandler alloc] init];
		
		//[[[NSUserDefaults standardUserDefaults] objectForKey:@"greenButtonRight"] integerValue]
		
		[handler changeWindowSize:roleNumber forWindow:windowUnderCursor];
		[handler release];
		
	} else {
		return event;
	}
	
	
	
	////////////////////////
	return nil;
}




CGEventRef EventFunc2(CGEventTapProxy proxy, CGEventType type,
                      CGEventRef event, void *refcon)
{
	//////CLog(@"hierbinich");
    
    NSEvent *myEvent = nil;
    
    @try {
        myEvent =  [NSEvent eventWithCGEvent:event];

    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
	
	//////CLog([myEvent description]);
	switch(myEvent.type){
            
			
		case NSRightMouseUp:
		{
			if([myEvent modifierFlags] & NSCommandKeyMask)
			{
				return HandleMouseEvent(1, event);
			}
			else {
				return HandleMouseEvent(0, event);
			}
            
            
		}
		case NSOtherMouseUp:
		{
			if([[[NSUserDefaults standardUserDefaults] objectForKey:@"otherMouseDoesCMDClick"] boolValue]) {
				return HandleMouseEvent(1, event);
			}
            
            
		}
            
            
            //case   37 :   {
            //				
            //		//	////CLog([ myEvent description]);
            //		SBMacWinHandler *handler = [[SBMacWinHandler alloc] init];
            //			[handler changeWindowSize:1];
            //			return nil;
            //		}
            //		case   NSEventTypeBeginGesture :   {
            //			////CLog(@"gesture");
            //			break;
            //		}
            
            
			
            //		case   NSEventTypeRotate :   {
            //				//////CLog([ myEvent description]);
            //			////CLog(@"rotate");
            //			break;
            //	
            //		}
            
			
	}
    
	
	// We must return the event for it to be useful.
	return event;
}



CGEventRef myCGEventCallback(CGEventTapProxy proxy, CGEventType type,
							 CGEventRef event, void *refcon)
{
	
	//////CLog(@"Event");
	if(type == kCGEventTapDisabledByTimeout || type == kCGEventTapDisabledByUserInput)
	{
		//////CLog(@"Tap disabled, enabling back!");
		
		CGEventTapEnable(eventTap, YES);
		
	}
	
	NSAutoreleasePool* pool = [[NSAutoreleasePool alloc] init];
	
	CGEventRef retVal = EventFunc2(proxy, type, event, refcon);
	
	[pool release];
	
	return retVal;
}



void startMonitoring2()
{
    
	CGEventMask eventMask;
	CFRunLoopSourceRef runLoopSource;
	
	// Create an event tap. We are interested in key presses.
    eventMask = (
                 NSRightMouseUpMask	  |
                 NSOtherMouseUpMask
                 //NSScrollWheelMask 
                 // NSEventMaskGesture       |
                 //							 NSEventMaskMagnify       |
                 //							 NSEventMaskSwipe         |
                 //							
                 //							 NSEventMaskRotate        |
                 //							 NSEventMaskBeginGesture  |
                 //							 NSEventMaskEndGesture
                 );
	eventTap = CGEventTapCreate(
								kCGHIDEventTap, kCGHeadInsertEventTap,
								kCGEventTapOptionListenOnly, eventMask, myCGEventCallback, nil);
	
	if (!eventTap) {
		////CLog(@"failed to create event tap\n");
		
		//[NSApp terminate: self];
		return;
	}
	
	// Create a run loop source.
	runLoopSource = CFMachPortCreateRunLoopSource(
												  kCFAllocatorDefault, eventTap, 0);
	// Create a run loop source.
	//runLoopSource = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, eventTap, 0);
	
	// Add to the current run loop.
	CFRunLoopAddSource(CFRunLoopGetCurrent(), runLoopSource, kCFRunLoopCommonModes);
	
	// Enable the event tap.
	CGEventTapEnable(eventTap, true);
	
	return;
}




-(void) checkMousePosition:(id)timerobj{
	
	
	SecondBarAppDelegate *delegate = [[NSApplication sharedApplication] delegate];
	NSPoint mousePosition1 = [delegate.sbWindowController.sbWindow mouseLocationOutsideOfEventStream];
	NSPoint mousePosition= [delegate.sbWindowController.sbWindow convertBaseToScreen:mousePosition1];
	NSRect examinedFrame = delegate.sbWindowController.sbWindow.frame;

	examinedFrame.size.height = 24;
	
			
	if(NSPointInRect(mousePosition, examinedFrame)) {
		if((
			mousePosition.x < self.currentButton.frame.origin.x+delegate.sbWindowController.sbWindow.frame.origin.x 
			||  mousePosition.x > delegate.sbWindowController.SBButton.frame.origin.x +delegate.sbWindowController.sbWindow.frame.origin.x 
			||  mousePosition.x >self.currentButton.frame.origin.x+self.currentButton.frame.size.width+delegate.sbWindowController.sbWindow.frame.origin.x) 
		   && (mousePosition.x <= delegate.sbWindowController.sbWindow.frame.origin.x+ [delegate.sbWindowController.sbWindow minSize].width-delegate.sbWindowController.SBButton.frame.size.width 
			   //||  mousePosition.x > delegate.sbWindowController.SBButton.frame.origin.x + delegate.sbWindowController.sbWindow.frame.origin.x)) {
			  
		  )) {
					mousePosition.y = delegate.sbWindowController.sbWindow.frame.origin.y+1;
			  	   SBMenuButton *button = (SBMenuButton*)[delegate.sbWindowController.contentView hitTest:[delegate.sbWindowController.sbWindow convertScreenToBase:mousePosition]];
				
				   [button colorizeBlue];
				   
				   [self.currentButton.menu cancelTrackingWithoutAnimation];
				   //[self clearMenu:self.currentButton.menu];
				   NSEvent *event =  [NSEvent mouseEventWithType:NSRightMouseDown
														location:[delegate.sbWindowController.sbWindow convertScreenToBase:mousePosition]
												   modifierFlags:0 // 0x100
													   timestamp:1
													windowNumber:[delegate.sbWindowController.sbWindow windowNumber]
														 context:[NSGraphicsContext currentContext]
													 eventNumber:1
													  clickCount:1
														pressure:1.0];
				   
				   
				   
				   [delegate.sbWindowController.sbWindow postEvent:event atStart:YES];
				   
			   
		   }
	}
	
	
	
	
}


- (void)buttonPressed:(NSNotification*)note {
	
	self.currentButton = (SBMenuButton *) [note object];
	if(self.currentButton.tag != 666) {
	self.timer = [NSTimer timerWithTimeInterval:0.01 target:self selector:@selector(checkMousePosition:) userInfo:nil repeats:TRUE];
	
	[[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSDefaultRunLoopMode];
	[[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSEventTrackingRunLoopMode];	
	}
	
}

- (void) checkPid {
	NSWorkspace *ws = [NSWorkspace sharedWorkspace];
	////CLog(@"x %i",menuItemCount);
	if (menuItemCount == 0 || [self.currentPid intValue] != [[[ws activeApplication] valueForKey:@"NSApplicationProcessIdentifier"] intValue] ) {
		////CLog(@"check failed");
		
		[self updateCurrentMenubarSoon];
		
	}


	
}

- (id)init {
	if (self = [super init]) {
		systemWide = AXUIElementCreateSystemWide();
		AXUIElementSetMessagingTimeout(systemWide,0.4);
		if ([[[NSUserDefaults standardUserDefaults] objectForKey:@"windowPositioningActivated"] boolValue]) {
			startMonitoring2();
		}
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(buttonPressed:) name:@"buttonPressed" object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(stop) name:@"windowHidden" object:nil];
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(start) name:@"windowVisible" object:nil];
		//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCurrentMenubar) name:@"windowDragged" object:nil];
		
		//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCurrentMenubar) name:@"windowDragged" object:nil];
		
		self.watching = YES;
		self.secondBarPid = [NSNumber numberWithInteger:getpid()];
		self.currentPid = [NSNumber numberWithInteger:-1];
		
		SecondBarAppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];
		[NSTimer scheduledTimerWithTimeInterval:0.34 target:appDelegate.windowMover selector:@selector(checkScreen) userInfo:nil repeats:YES];
		
		[NSTimer scheduledTimerWithTimeInterval:2 target:self selector:@selector(checkPid) userInfo:nil repeats:YES];
		
		self.theLock=[[NSLock alloc] init];
		

		
		[[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
															   selector:@selector(updateCurrentMenubarSoon)
																   name:NSWorkspaceDidActivateApplicationNotification
																 object:nil];
		
		[[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
															   selector:@selector(updateCurrentMenubarSoon)
																   name:NSWorkspaceDidDeactivateApplicationNotification
																 object:nil];
		
		[[[NSWorkspace sharedWorkspace] notificationCenter] addObserver:self
															   selector:@selector(updateCurrentMenubarSoon)
																   name:NSWorkspaceDidLaunchApplicationNotification
																 object:nil];

		
		[self updateCurrentMenubarSoon];
		[self performSelector:@selector(updateCurrentMenubarSoon) withObject:nil afterDelay:1];
	
		
		self.everythingEnabled = NO;
		
	}
	return self;
}


#pragma mark -
#pragma mark CurrentMenubarMethods
-(void) updateCurrentMenubarSoon {

	[NSThread detachNewThreadSelector:@selector(updateCurrentMenubar) toTarget:self withObject:nil];	
}

-(void) updateCurrentMenubar {
	if (!APPDEL.sbWindowController) {
        //CLog(@"return");
        
        return;
    }
	//SecondBarAppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	
	
	[self.theLock lock];
	BOOL checkAgain = NO;
	
	NSWorkspace *ws = [NSWorkspace sharedWorkspace];
	menuItemCount = 0;
	self.lastPid = self.currentPid;	
	//////CLog([[ws activeApplication] valueForKey:@"NSApplicationName"]);
	
	if ( [[[ws activeApplication] valueForKey:@"NSApplicationProcessIdentifier"] intValue]  != [self.secondBarPid intValue]) {
		self.currentPid = [[ws activeApplication] valueForKey:@"NSApplicationProcessIdentifier" ];
		
		if(NO) {
			//if ([self.currentPid intValue] == [self.lastPid intValue]  && YES) {
			
			//TODO: here some lazy updating could take place
			
		} else {
			
			// get the currently active application  
			AXUIElementRef app = AXUIElementCreateApplication([self.currentPid intValue]);
			AXUIElementSetMessagingTimeout(app,0.4);
			AXUIElementRef menubar = (AXUIElementRef) [SBApiAccess 
													   valueOfExistingAttribute:kAXMenuBarAttribute 
													   ofUIElement:app];
			CFRelease(app);
			
			if(menubar) {
				NSMutableArray *arrayx = [[[NSMutableArray alloc] init] autorelease];
				self.menubarItems = arrayx;
				self.menubarItems = (NSMutableArray*)[SBApiAccess 
													  valueOfExistingAttribute:kAXVisibleChildrenAttribute 
													  ofUIElement:menubar];
				
				if (self.menubarItems) {
					SecondBarAppDelegate *appDelegate = [[NSApplication sharedApplication] delegate];
					
					CGFloat positionx = 0.0;
					NSString *labelText = @"";
					
					NSView *newView = [[[NSView alloc] initWithFrame:appDelegate.sbWindowController.contentView.frame] autorelease];
					for (id item in self.menubarItems)
					{
						labelText = [NSString stringWithFormat:@" %@%@",[SBApiAccess descriptionOfValue:item
																						   beingVerbose:TRUE],@" "];
						
						if ([labelText isEqualToString:@"    "]) {
							checkAgain = YES;
						}
						SBMenuButton *button = [[[SBMenuButton alloc] initWithFrame:NSRectFromCGRect(CGRectMake(positionx, 0.0, 100.0, 22.0))] autorelease];
						button.title = labelText;
					
						button.tag = [self.menubarItems indexOfObject:item];
						if(button.tag < 2) {
							if(button.tag == 0) {
								
								[button setFont:[NSFont systemFontOfSize:17]];

								[button setTitle:@"    "];
								
							}
							else {
								[button setFont:[NSFont boldSystemFontOfSize:14]];
							}

						}
					//	[[button cell] setBackgroundStyle:NSBackgroundStyleRaised];
						[button sizeToFit];
						NSRect newFrame = NSRectFromCGRect(CGRectMake(positionx,0.0, button.frame.size.width,22));
						button.frame = newFrame;
						
						
						//[button setTarget:self];
						//[button setAction:@selector(buttonAction:)];
						
						positionx += button.frame.size.width;
						
						
						
						//this is for changing the minsize of the window if the buttons change:
						NSSize minSize;
						minSize.width =positionx+appDelegate.sbWindowController.SBButton.frame.size.width;
						
						
						
						NSMenu *dummyMenu = [[[NSMenu alloc] initWithTitle:@"dummy"] autorelease];
						
						NSMenuItem *dummyItem = [NSMenuItem separatorItem];
						[dummyItem setHidden:YES];
						[dummyItem setRepresentedObject:item];
						[dummyMenu addItem:dummyItem];
						dummyMenu.delegate = self;
											
						//[appDelegate.sbWindowController addButton:button];
						button.menu = dummyMenu ;
						
						[newView addSubview:button];
						menuItemCount++;
					
						[appDelegate.sbWindowController.sbWindow setMinSize:minSize];
						[appDelegate.sbWindowController.sbWindow adjustWindowWidth];
						
					}
					[appDelegate.sbWindowController removeAllButtons];
					[appDelegate.sbWindowController.contentView addSubview:newView];
					
					
				} else {
					self.currentPid = [NSNumber numberWithInt:-1];
				}

			}else {
				self.currentPid = [NSNumber numberWithInt:-1];
			}
			
		}
	}
	if(checkAgain) {
		[self performSelectorOnMainThread:@selector(updateMenubarAfterDelay:) withObject:[NSNumber numberWithFloat:2] waitUntilDone:NO];
		
	}
	[self.theLock unlock];
	[pool drain];
}

-(void)updateMenubarAfterDelay:(NSNumber *)delayTimeNumber{
    NSTimeInterval delayTime= 1;
    if (delayTime) {
        delayTime = [delayTimeNumber floatValue];
    }
    NSLog(@"updating after delay");
    [NSTimer scheduledTimerWithTimeInterval:delayTime target:self selector:@selector(updateCurrentMenubarSoon) userInfo:nil repeats:NO];
    
}

#pragma mark -
#pragma mark NSMenu Methods
- (BOOL)itemIsEnabled:(AXUIElementRef) item {
	AXUIElementRef enabledAttr = (AXUIElementRef) [SBApiAccess 
												   valueOfExistingAttribute:kAXEnabledAttribute 
												   ofUIElement:item];
	
	BOOL enabled = [(NSString*) enabledAttr boolValue];
    return enabled;
}

- (BOOL)itemHasMarkChar:(AXUIElementRef) item {
	AXUIElementRef enabledAttr = (AXUIElementRef) [SBApiAccess 
												   valueOfExistingAttribute:kAXMenuItemMarkCharAttribute
												   ofUIElement:item];
	
	if (enabledAttr) {
		return YES;
	}
	
    return NO;
}



- (void)menuDidClose:(NSMenu *)menu {
	if(![menu supermenu]) {
		[self.timer invalidate];
		self.timer= nil;
	}
	//	[NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(clearMenuWithTimer:) userInfo:menu repeats:NO];
	
	
}



- (void)menuNeedsUpdate:(NSMenu *)theMenu {
	//////CLog(@"update menu");
	
	
	
	if([theMenu.title isEqualToString:@"dummy"]) {
		NSMenuItem *dummyElement = [[[theMenu itemAtIndex:0] copy] autorelease];
		[theMenu removeAllItems];
		[theMenu addItem:dummyElement];
        
        if (![dummyElement representedObject]) {
            //CLog(@"no represented objects!!!");
            [self updateCurrentMenubarSoon];
        }
		AXUIElementRef dummyRef = (AXUIElementRef)[dummyElement representedObject];
        
        
		//	[theMenu removeItemAtIndex:0];
		
		NSLog(@"update menu");
		[self updateNSMenuForMenubarItem:dummyRef andMenu:theMenu];
        
        
        NSLog(@"itemcount %i",[[theMenu itemArray] count] );
        if ([[theMenu itemArray] count] <= 1) {
      
            [self performSelectorOnMainThread:@selector(updateMenubarAfterDelay:) withObject:[NSNumber numberWithFloat:1] waitUntilDone:NO];
        }
	}
}

#pragma mark -
- (void) updateNSMenuForMenubarItem:(AXUIElementRef)theItem andMenu:(NSMenu*)theMenu {
	
	NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
	AXUIElementSetMessagingTimeout(theItem,0.2);
	NSArray *axMenu= (NSArray*)[SBApiAccess 
								valueOfExistingAttribute:kAXChildrenAttribute
								ofUIElement:(AXUIElementRef)theItem];
	
	if(axMenu) {
		
		NSArray *subItems = [SBApiAccess 
							 valueOfExistingAttribute:kAXChildrenAttribute
							 ofUIElement:(AXUIElementRef)[axMenu objectAtIndex:0]];
		
		NSString *subitemLabel;
		theMenu.delegate = self;
		for (id subItem in subItems) {
			if([SBApiAccess 
				valueOfExistingAttribute:kAXPositionAttribute
				ofUIElement:(AXUIElementRef)subItem]) {
				
				subitemLabel = [SBApiAccess descriptionOfValue:subItem
												  beingVerbose:TRUE];
				
				NSMenuItem *newItem;
				if ([subitemLabel isEqualToString:@""] || [subitemLabel isEqualToString:@"-"]) {
					newItem = [NSMenuItem separatorItem];
				}
				else
				{
					//TODO: option to show only active items
					newItem = [[[NSMenuItem alloc] initWithTitle:subitemLabel
														  action:@selector(menuItemSelected:)
												   keyEquivalent:@""] autorelease]; 
					
					
					NSString *key = [SBApiAccess 
									 valueOfExistingAttribute:kAXMenuItemCmdCharAttribute
									 ofUIElement:(AXUIElementRef)subItem];
					NSString *modifier = [SBApiAccess 
										  valueOfExistingAttribute:kAXMenuItemCmdModifiersAttribute
										  ofUIElement:(AXUIElementRef)subItem];
					if(key && modifier) {
						
                        
                        if ([modifier intValue] == 1) {
                            //[newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                            [newItem setKeyEquivalentModifierMask:NSCommandKeyMask];
                            [newItem setKeyEquivalent:key];
                            
                        } else if ([modifier intValue] == 2) {
                            
                            //    [newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                            [newItem setKeyEquivalentModifierMask:NSAlternateKeyMask | NSCommandKeyMask];
                            [newItem setKeyEquivalent:[key lowercaseString]];
                            
                            
                            
                        } else if ([modifier intValue] == 3) {
                            //[newItem setKeyEquivalentModifierMask:3];
                            [newItem setKeyEquivalentModifierMask:NSAlternateKeyMask | NSCommandKeyMask];
                            [newItem setKeyEquivalent:key];
                            
                        } else if ([modifier intValue] == 4) {
                            [newItem setKeyEquivalentModifierMask:NSCommandKeyMask |NSControlKeyMask];
                            [newItem setKeyEquivalent:[key lowercaseString]];
                        }
                  else if ([modifier intValue] == 5) {
                      [newItem setKeyEquivalentModifierMask:NSCommandKeyMask |NSControlKeyMask|NSShiftKeyMask];
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  }
                   
                        
                        else if ([modifier intValue] == 6) {
                            //[newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                            [newItem setKeyEquivalentModifierMask:NSCommandKeyMask |NSControlKeyMask|NSAlternateKeyMask];
                            
                            [newItem setKeyEquivalent:[key lowercaseString]];
                            
                            
                  }else if ([modifier intValue] == 7) {
                      [newItem setKeyEquivalentModifierMask:NSCommandKeyMask |NSControlKeyMask|NSAlternateKeyMask| NSShiftKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];

                      
                      
                  } else if ([modifier intValue] == 9) {
                            [newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                      [newItem setKeyEquivalent:[key lowercaseString]];

                  }else if ([modifier intValue] == 10) {
                      //[newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                      [newItem setKeyEquivalentModifierMask:NSAlternateKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  }else if ([modifier intValue] == 11) {
                      //[newItem setKeyEquivalentModifierMask:NSShiftKeyMask];
                      [newItem setKeyEquivalentModifierMask:NSAlternateKeyMask|NSShiftKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  } else if ([modifier intValue] == 12) {
                      [newItem setKeyEquivalentModifierMask:NSControlKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  }else if ([modifier intValue] == 13) {
                      [newItem setKeyEquivalentModifierMask:NSControlKeyMask|NSShiftKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  } else if ([modifier intValue] == 14) {
                      [newItem setKeyEquivalentModifierMask:NSControlKeyMask|NSAlternateKeyMask];
                      
                      [newItem setKeyEquivalent:[key lowercaseString]];
                  } else {
                            [newItem setKeyEquivalent:[key lowercaseString]];
                            
                        }
						
					}
					
					if( [self itemHasMarkChar:(AXUIElementRef) subItem]) {
						[newItem setState:NSOnState];
					}
					
					if ([self itemIsEnabled:(AXUIElementRef) subItem] || self.everythingEnabled) {
						[newItem setEnabled:YES];
						[newItem setRepresentedObject:subItem];
						[newItem setTarget:self];
						
					} else {
						[newItem setEnabled:NO];
					}
				}
				
				if (![subitemLabel isEqualToString:@"    "]) {
					[theMenu addItem:newItem];
				}
				
				
				
				
				
				
				
				SecondBarAppDelegate *delegate = [[NSApplication sharedApplication] delegate];
				NSPoint mousePosition1 = [delegate.sbWindowController.sbWindow mouseLocationOutsideOfEventStream];
				NSPoint mousePosition= [delegate.sbWindowController.sbWindow convertBaseToScreen:mousePosition1];
				NSRect examinedFrame = delegate.sbWindowController.sbWindow.frame;
				
				examinedFrame.size.height = 24;
				
				
				if(NSPointInRect(mousePosition, examinedFrame)) {
					if((
						mousePosition.x < self.currentButton.frame.origin.x+delegate.sbWindowController.sbWindow.frame.origin.x 
						||  mousePosition.x > delegate.sbWindowController.SBButton.frame.origin.x +delegate.sbWindowController.sbWindow.frame.origin.x 
						||  mousePosition.x >self.currentButton.frame.origin.x+self.currentButton.frame.size.width+delegate.sbWindowController.sbWindow.frame.origin.x) 
					   && (mousePosition.x <= delegate.sbWindowController.sbWindow.frame.origin.x+ [delegate.sbWindowController.sbWindow minSize].width-delegate.sbWindowController.SBButton.frame.size.width 
						   //||  mousePosition.x > delegate.sbWindowController.SBButton.frame.origin.x + delegate.sbWindowController.sbWindow.frame.origin.x)) {
						   
						   )) {
									return;
						   
						   
					   }
				}
				
				
				
				
				
				
				
				
				
				NSArray *axSubMenu= [SBApiAccess 
									 valueOfExistingAttribute:kAXChildrenAttribute
									 ofUIElement:(AXUIElementRef)subItem];
				
				if ([axSubMenu count] > 0 && ![subitemLabel isEqualToString:@"    "] ) {
					NSMenu *dummyMenu = [[[NSMenu alloc] initWithTitle:@"dummy"] autorelease];
					NSMenuItem *dummyItem = [NSMenuItem separatorItem];
					[dummyItem setHidden:YES];
					
					[dummyItem setRepresentedObject:subItem];
					[dummyMenu addItem:dummyItem];
					dummyMenu.delegate =self;
					[theMenu setSubmenu:dummyMenu forItem:newItem];
				}
			}
		}
	}
	[pool release];
	
}

-(IBAction)menuItemSelected:(id)sender {

	NSMenuItem *item = (NSMenuItem *)sender;
	AXUIElementRef selectedElement =  (AXUIElementRef) [item representedObject];
	//NSWorkspace *ws = [NSWorkspace sharedWorkspace];
	//	NSString *appPath = [self.currentApplication objectForKey:@"NSApplicationPath"];
	//	[ws launchApplication:appPath]; 
	AXUIElementPerformAction(selectedElement, kAXPressAction);
    
    [self updateMenubarAfterDelay:[NSNumber numberWithFloat:0.5]];

	
}


#pragma mark -
#pragma mark Right Mouse recognition








#pragma mark -

- (void)dealloc {
	
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	[theLock release];
	[observer release];
	[menubarItems release];
	[super dealloc];
}

@end
