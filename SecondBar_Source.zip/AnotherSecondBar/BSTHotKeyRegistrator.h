//
//  BSTHotKeyRegistrator.h
//  BetterSnapTool
//
//  Created by Andreas Hegenberg on 16.11.10.
//  Copyright 2010 TUM. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface BSTHotKeyRegistrator : NSObject {
	NSDictionary *registeredHotKeys;
}

@property (nonatomic, retain) NSDictionary *registeredHotKeys;

@end
