//
//  CustomWindow.h
//  SecondBar
//
//  Created by Andreas Hegenberg on 22.08.09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <AppKit/AppKit.h>

@class SBAccessibility;

@interface CustomWindow : NSPanel {
    // This point is used in dragging to mark the initial click location
    NSPoint initialLocation;
	SBAccessibility *menubarItems;
	NSInteger currentScreen;
	BOOL currentlyDragging;
	BOOL visible;
	CGFloat transparency;
}

@property (assign) NSPoint initialLocation;
@property (nonatomic,retain) SBAccessibility *menubarItems;
@property (nonatomic) NSInteger currentScreen;
@property (nonatomic) BOOL currentlyDragging;
@property (nonatomic) BOOL visible;
@property (nonatomic) CGFloat transparency;

-(void)adjustWindowWidth;
- (IBAction) changeScreen:(id)sender;
-(void) setScreenTo:(NSInteger)screenNumber;
@end

