//
//  PTHotKeyCenter.m
//  Protein
//
//  Created by Quentin Carnicelli on Sat Aug 02 2003.
//  Updated by Joel Levin in August 2009 for Snow Leopard/64-bit
//  Copyright (c) 2003 Quentin D. Carnicelli. All rights reserved.
//

#import "PTHotKeyCenter.h"
#import "PTHotKey.h"
#import "PTKeyCombo.h"
#import <Carbon/Carbon.h>
#import <ShortcutRecorder/ShortcutRecorder.h>


static UInt32 nextHotKeyID = 1;

@interface PTHotKeyCenter (Private)

- (PTHotKey*)_hotKeyForCarbonHotKey: (EventHotKeyRef)carbonHotKey;
- (EventHotKeyRef)_carbonHotKeyForHotKey: (PTHotKey*)hotKey;

- (void)_updateEventHandler;
- (BOOL)_hotKeyDown: (PTHotKey*)hotKey;
- (void)_hotKeyUp: (PTHotKey*)hotKey;
static OSStatus hotKeyEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void* refCon );

@end

@implementation PTHotKeyCenter

static id _sharedHotKeyCenter = nil;

+ (PTHotKeyCenter *)sharedCenter
{
	if( _sharedHotKeyCenter == nil )
	{
		_sharedHotKeyCenter = [[self alloc] init];
	}
	
	return _sharedHotKeyCenter;
}

- (id)init
{
	self = [super init];
	
	if( self )
	{
		mHotKeys = [[NSMutableDictionary alloc] init];
		mHotKeyIDs = [[NSMutableDictionary alloc] init];
	}
	
	return self;
}

- (void)dealloc
{
	[mHotKeys release];
	[mHotKeyIDs release];
	[super dealloc];
}

#pragma mark -

- (BOOL)registerHotKey: (PTHotKey*)hotKey
{
	////////CLog(@"ya");
	OSStatus err;
	EventHotKeyID hotKeyID;
	EventHotKeyRef carbonHotKey;
	NSValue* key;

	if( [[self allHotKeys] containsObject: hotKey] == YES )
		[self unregisterHotKey: hotKey];
	
	if( [[hotKey keyCombo] isValidHotKeyCombo] == NO )
		return YES;
	
	hotKeyID.signature = 'HCHk';
	hotKeyID.id = nextHotKeyID;
	
	hotKey.associatedID = hotKeyID.id;
	
	[mHotKeyIDs setObject:hotKey forKey:[[NSNumber numberWithUnsignedLong:nextHotKeyID] stringValue]];
	
	err = RegisterEventHotKey(  [[hotKey keyCombo] keyCode],
								[[hotKey keyCombo] modifiers],
								hotKeyID,
								GetEventDispatcherTarget(),
								0,
								&carbonHotKey );

	if( err )
		return NO;

	key = [NSValue valueWithPointer: carbonHotKey];
	if( hotKey && key )
		[mHotKeys setObject: hotKey forKey: key];

	[self _updateEventHandler];
	
	nextHotKeyID++;
	
	return YES;
}

- (void) unregisterHotKeyWithKeyCode:(NSInteger)code andModifier:(NSInteger)modifier {
	////////CLog(@"unregister ding");
	NSEnumerator *enumerator = [mHotKeys keyEnumerator];
	id aKey = nil;
	while ( (aKey = [enumerator nextObject]) != nil) {
		PTHotKey *theHotKey = [mHotKeys objectForKey:aKey];
		
		if ([[theHotKey keyCombo] keyCode] == code && [[theHotKey keyCombo] modifiers] == modifier ) {
	
			OSStatus err;
				
			err = UnregisterEventHotKey([self _carbonHotKeyForHotKey:theHotKey]);
		
			[mHotKeys removeObjectForKey: aKey];
			
			[mHotKeyIDs removeObjectForKey:[[NSNumber numberWithUnsignedLong:theHotKey.associatedID] stringValue]];
			
			
			[self _updateEventHandler];
			return;
		}
		
	}
}

- (void)unregisterHotKey: (PTHotKey*)hotKey
{
	////////CLog(@"unregister");
	OSStatus err;
	EventHotKeyRef carbonHotKey;
	NSValue* key;

	if( [[self allHotKeys] containsObject: hotKey] == NO )
		return;
	
	carbonHotKey = [self _carbonHotKeyForHotKey: hotKey];
	NSAssert( carbonHotKey != nil, @"" );

	err = UnregisterEventHotKey( carbonHotKey );
	//Watch as we ignore 'err':

	key = [NSValue valueWithPointer: carbonHotKey];
	[mHotKeys removeObjectForKey: key];
	
	[mHotKeyIDs removeObjectForKey:[[NSNumber numberWithUnsignedLong:hotKey.associatedID] stringValue]];
	
	[self _updateEventHandler];

	//See that? Completely ignored
}

- (NSArray*)allHotKeys
{
	return [mHotKeys allValues];
}

- (PTHotKey*)hotKeyWithIdentifier: (id)ident
{
	NSEnumerator* hotKeysEnum = [[self allHotKeys] objectEnumerator];
	PTHotKey* hotKey;
	
	if( !ident )
		return nil;
	
	while( (hotKey = [hotKeysEnum nextObject]) != nil )
	{
		if( [[hotKey identifier] isEqual: ident] )
			return hotKey;
	}

	return nil;
}

#pragma mark -

- (PTHotKey*)_hotKeyForCarbonHotKey: (EventHotKeyRef)carbonHotKey
{
	NSValue* key = [NSValue valueWithPointer: carbonHotKey];
	return [mHotKeys objectForKey: key];
}

- (EventHotKeyRef)_carbonHotKeyForHotKey: (PTHotKey*)hotKey
{
	NSArray* values;
	NSValue* value;
	
	values = [mHotKeys allKeysForObject: hotKey];
	NSAssert( [values count] == 1, @"Failed to find Carbon Hotkey for HotKey" );
	
	value = [values lastObject];
	
	return (EventHotKeyRef)[value pointerValue];
}

- (void)_updateEventHandler
{
	if( [mHotKeys count] && mEventHandlerInstalled == NO )
	{
		EventTypeSpec eventSpec[2] = {
			{ kEventClassKeyboard, kEventHotKeyPressed },
			{ kEventClassKeyboard, kEventHotKeyReleased }
		};    

		InstallEventHandler( GetEventDispatcherTarget(),
							 (EventHandlerProcPtr)hotKeyEventHandler, 
							 2, eventSpec, nil, nil);
	
		mEventHandlerInstalled = YES;
	}
}


- (BOOL)_hotKeyDown: (PTHotKey*)hotKey
{
	return [hotKey invokeBSTAction];
}

- (void)_hotKeyUp: (PTHotKey*)hotKey
{
}

- (void)sendEvent: (NSEvent*)event
{
	short subType;
	EventHotKeyRef carbonHotKey;
	
	if( [event type] == NSSystemDefined )
	{
		subType = [event subtype];
		
		if( subType == 6 ) //6 is hot key down
		{
			carbonHotKey= (EventHotKeyRef)[event data1]; //data1 is our hot key ref
			if( carbonHotKey != nil )
			{
				PTHotKey* hotKey = [self _hotKeyForCarbonHotKey: carbonHotKey];
				[self _hotKeyDown: hotKey];
			}
		}
		else if( subType == 9 ) //9 is hot key up
		{
			carbonHotKey= (EventHotKeyRef)[event data1];
			if( carbonHotKey != nil )
			{
				PTHotKey* hotKey = [self _hotKeyForCarbonHotKey: carbonHotKey];
				[self _hotKeyUp: hotKey];
			}
		}
	}
}

- (OSStatus)sendCarbonEvent: (EventRef)event
{
	OSStatus err;
	EventHotKeyID hotKeyID;
	PTHotKey* hotKey;

	NSAssert( GetEventClass( event ) == kEventClassKeyboard, @"Unknown event class" );

	err = GetEventParameter(	event,
								kEventParamDirectObject, 
								typeEventHotKeyID,
								nil,
								sizeof(EventHotKeyID),
								nil,
								&hotKeyID );
	if( err )
		return err;
	
	
	
	

	NSAssert( hotKeyID.signature == 'HCHk', @"Invalid hot key id" );
	NSAssert( hotKeyID.id != 0, @"Invalid hot key id" );

	hotKey = (PTHotKey*)[mHotKeyIDs objectForKey:[[NSNumber numberWithUnsignedLong:hotKeyID.id] stringValue]];

		
	switch( GetEventKind( event ) )
	{
		case kEventHotKeyPressed:
			if ([self _hotKeyDown: hotKey] == NO) {
				
				[self unregisterHotKey:hotKey];
				
			}
		break;

		case kEventHotKeyReleased:
			[self _hotKeyUp: hotKey];
		break;

		default:
			NSAssert( 0, @"Unknown event kind" );
		break;
	}
	
	return noErr;
}

static OSStatus hotKeyEventHandler(EventHandlerCallRef inHandlerRef, EventRef inEvent, void* refCon )
{

	return [[PTHotKeyCenter sharedCenter] sendCarbonEvent: inEvent];
}

@end
